package com.example.aibridge;

import android.content.Context;
import android.content.SharedPreferences;

final class Prefs {
    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("aibridge", Context.MODE_PRIVATE);
    }

    static String get(Context c, String k, String def) { return sp(c).getString(k, def); }

    static void set(Context c, String k, String v) { sp(c).edit().putString(k, v).apply(); }

    static boolean lang(Context c) { return sp(c).getBoolean("th", false); }

    static void setLang(Context c, boolean th) { sp(c).edit().putBoolean("th", th).apply(); }
}
