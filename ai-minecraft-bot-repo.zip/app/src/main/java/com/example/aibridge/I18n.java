package com.example.aibridge;

import java.util.HashMap;
import java.util.Map;

/** Two languages (English / Thai). Each entry: {english, thai}. */
final class I18n {
    static volatile boolean th = false;
    private static final Map<String, String[]> M = new HashMap<>();

    private static void a(String k, String en, String thai) { M.put(k, new String[]{en, thai}); }

    static {
        a("title", "AI Bridge", "AI Bridge");
        a("lang_btn", "ไทย", "EN");
        a("api_link", "AI link (base URL)", "ลิงก์ AI (base URL)");
        a("api_link_hint", "https://api.openai.com/v1", "https://api.openai.com/v1");
        a("api_key", "AI key", "คีย์ AI");
        a("model", "Model name", "ชื่อโมเดล");
        a("model_hint", "e.g. gpt-4o-mini", "เช่น gpt-4o-mini");
        a("goal", "What should the AI do?", "ให้ AI ทำอะไร?");
        a("goal_default", "Stay near the player, gather wood, and be helpful.", "อยู่ใกล้ผู้เล่น เก็บไม้ และช่วยเหลือผู้เล่น");
        a("start", "Start", "เริ่ม");
        a("stop", "Stop", "หยุด");
        a("save_goal", "Update goal", "อัปเดตเป้าหมาย");
        a("need_fields", "Fill in the AI link, key and model first.", "กรอกลิงก์ AI คีย์ และชื่อโมเดลก่อน");
        a("how", "1) Press Start.\n2) In Minecraft type:  /connect 127.0.0.1:3000\n3) The AI bot joins and starts playing.\nThe world needs the AI Player Bot add-on, Beta APIs and cheats.",
                "1) กด เริ่ม\n2) ใน Minecraft พิมพ์:  /connect 127.0.0.1:3000\n3) บอท AI จะเข้าเกมและเริ่มเล่น\nโลกต้องมีแอดออน AI Player Bot เปิด Beta APIs และเปิดโกง");
        a("st_ai", "AI: ", "AI: ");
        a("st_mc", "Minecraft: ", "Minecraft: ");
        a("running", "running", "ทำงานอยู่");
        a("stopped", "stopped", "หยุดอยู่");
        a("connected", "connected", "เชื่อมต่อแล้ว");
        a("waiting", "waiting for /connect", "รอ /connect");
        a("log", "Log", "บันทึก");
        a("notif", "Bridge is running (port 3000)", "บริดจ์ทำงานอยู่ (พอร์ต 3000)");
        a("log_listen", "Listening on 127.0.0.1:3000", "รอรับการเชื่อมต่อที่ 127.0.0.1:3000");
        a("log_mc_on", "Minecraft connected", "Minecraft เชื่อมต่อแล้ว");
        a("log_mc_off", "Minecraft disconnected", "Minecraft หลุดการเชื่อมต่อ");
        a("log_link_ok", "Add-on replies OK via ", "แอดออนตอบกลับได้ผ่าน ");
        a("log_no_reply", "No reply from the add-on. Is it installed and active in this world (Beta APIs + cheats)? Retrying...",
                "แอดออนไม่ตอบกลับ ติดตั้งและเปิดใช้ในโลกนี้แล้วหรือยัง (Beta APIs + เปิดโกง)? กำลังลองใหม่...");
        a("log_bot_ready", "Bot is in the game", "บอทอยู่ในเกมแล้ว");
        a("log_bot_wait", "Waiting for the bot to spawn...", "กำลังรอบอทเกิด...");
        a("log_bot_fail", "The bot did not spawn. Check /scriptevent ai:cmd status in game.", "บอทไม่เกิด ลองพิมพ์ /scriptevent ai:cmd status ในเกม");
        a("log_http", "AI request failed: ", "เรียก AI ไม่สำเร็จ: ");
    }

    static String t(String k) {
        String[] v = M.get(k);
        if (v == null) return k;
        return th ? v[1] : v[0];
    }

    static String en(String k) {
        String[] v = M.get(k);
        return v == null ? k : v[0];
    }
}
