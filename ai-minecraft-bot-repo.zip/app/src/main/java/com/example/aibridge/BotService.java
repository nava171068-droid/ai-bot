package com.example.aibridge;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

/** Keeps the WebSocket server and the AI loop alive while Minecraft is in the foreground. */
public class BotService extends Service {
    private WsHub hub;
    private Brain brain;
    private Thread brainThread;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        I18n.th = Prefs.lang(this);
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("bridge", "AI Bridge", NotificationManager.IMPORTANCE_LOW));
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, "bridge")
                .setContentTitle("AI Bridge")
                .setContentText(I18n.t("notif"))
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(pi)
                .build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);

        if (hub != null) return START_NOT_STICKY;
        try {
            hub = new WsHub(3000);
            hub.start();
        } catch (Exception e) {
            Bus.log("cannot start server: " + e);
            stopSelf();
            return START_NOT_STICKY;
        }
        brain = new Brain(getApplicationContext(), hub);
        brainThread = new Thread(brain, "ai-brain");
        brainThread.start();
        Bus.running = true;
        Bus.fire();
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        if (brain != null) brain.stop = true;
        if (brainThread != null) brainThread.interrupt();
        final WsHub h = hub;
        if (h != null) {
            new Thread(new Runnable() {
                public void run() { try { h.stop(300); } catch (Exception ignored) { } }
            }).start();
        }
        hub = null;
        Bus.running = false;
        Bus.mc = false;
        Bus.fire();
        super.onDestroy();
    }
}
