package com.example.aibridge;

import org.java_websocket.WebSocket;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;
import org.json.JSONObject;

import java.net.InetSocketAddress;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * WebSocket server that Minecraft connects to with  /connect 127.0.0.1:3000.
 * Sends commands (/scriptevent ai:cmd ...) into the game and collects the "[ai] {json}" lines the add-on prints.
 */
final class WsHub extends WebSocketServer {
    final LinkedBlockingQueue<JSONObject> events = new LinkedBlockingQueue<>();
    private volatile WebSocket mc;
    private final java.util.HashMap<String, String[]> parts = new java.util.HashMap<>();
    private int rawLogged = 0;

    WsHub(int port) {
        super(new InetSocketAddress("127.0.0.1", port));
        setReuseAddr(true);
        setConnectionLostTimeout(0);
    }

    boolean connected() {
        WebSocket c = mc;
        return c != null && c.isOpen();
    }

    @Override public void onStart() { Bus.log(I18n.t("log_listen")); }

    @Override public void onOpen(WebSocket c, ClientHandshake h) {
        mc = c;
        Bus.mc = true;
        Bus.log(I18n.t("log_mc_on"));
        try {
            JSONObject header = new JSONObject();
            header.put("version", 1);
            header.put("requestId", UUID.randomUUID().toString());
            header.put("messagePurpose", "subscribe");
            header.put("messageType", "commandRequest");
            JSONObject body = new JSONObject();
            body.put("eventName", "PlayerMessage");
            JSONObject o = new JSONObject();
            o.put("header", header);
            o.put("body", body);
            c.send(o.toString());
        } catch (Exception e) {
            Bus.log("subscribe failed: " + e);
        }
        Bus.fire();
    }

    @Override public void onClose(WebSocket c, int code, String reason, boolean remote) {
        if (c == mc) {
            mc = null;
            Bus.mc = false;
            events.clear();
            Bus.log(I18n.t("log_mc_off"));
            Bus.fire();
        }
    }

    @Override public void onMessage(WebSocket c, String m) {
        try {
            JSONObject j = new JSONObject(m);
            JSONObject h = j.optJSONObject("header");
            JSONObject b = j.optJSONObject("body");
            if (h == null || b == null) return;
            String purpose = h.optString("messagePurpose");
            if ("event".equals(purpose) && "PlayerMessage".equals(h.optString("eventName"))) {
                String msgText = b.optString("message");
                if (!msgText.contains("[ai") && rawLogged < 25) {
                    rawLogged++;
                    Bus.log("mc chat: " + b.optString("type") + " / " + b.optString("sender") + " / " + (msgText.length() > 60 ? msgText.substring(0, 60) : msgText));
                }
                handleText(msgText);
            } else if ("commandResponse".equals(purpose)) {
                int sc = b.optInt("statusCode", 0);
                if (sc != 0) Bus.log("command failed (" + sc + "): " + b.optString("statusMessage"));
            } else if ("error".equals(purpose)) {
                Bus.log("minecraft error: " + b.optString("statusMessage", m));
            }
        } catch (Exception e) {
            Bus.log("bad message: " + e);
        }
    }

    @Override public void onError(WebSocket c, Exception e) { Bus.log("ws error: " + e); }

    private void handleText(String text) {
        String s = null;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\[ai#(\\d+)\\.(\\d+)/(\\d+)\\] ").matcher(text);
        if (m.find()) {
            String id = m.group(1);
            int i = Integer.parseInt(m.group(2)), n = Integer.parseInt(m.group(3));
            String piece = text.substring(m.end());
            synchronized (parts) {
                String[] arr = parts.get(id);
                if (arr == null || arr.length != n) { arr = new String[n]; parts.put(id, arr); }
                if (i >= 0 && i < n) arr[i] = piece;
                StringBuilder sb = new StringBuilder();
                for (String p : arr) { if (p == null) return; sb.append(p); }
                parts.remove(id);
                if (parts.size() > 50) parts.clear();
                s = sb.toString().trim();
            }
        } else {
            int i = text.indexOf("[ai] ");
            if (i < 0) return;
            s = text.substring(i + 5).trim();
        }
        try {
            events.offer(new JSONObject(s));
        } catch (Exception e) {
            Bus.log("unreadable add-on line: " + (s.length() > 120 ? s.substring(0, 120) + "..." : s));
        }
    }

    /** Runs a command in the game, as the player who did /connect. */
    boolean send(String commandLine) {
        WebSocket c = mc;
        if (c == null || !c.isOpen()) return false;
        try {
            JSONObject header = new JSONObject();
            header.put("version", 1);
            header.put("requestId", UUID.randomUUID().toString());
            header.put("messagePurpose", "commandRequest");
            header.put("messageType", "commandRequest");
            JSONObject origin = new JSONObject();
            origin.put("type", "player");
            JSONObject body = new JSONObject();
            body.put("version", 1);
            body.put("commandLine", commandLine);
            body.put("origin", origin);
            JSONObject o = new JSONObject();
            o.put("header", header);
            o.put("body", body);
            c.send(o.toString());
            return true;
        } catch (Exception e) {
            Bus.log("send failed: " + e);
            return false;
        }
    }

    /** Waits for the next add-on event named one of `names` (an "error" event always counts). null on timeout. */
    JSONObject await(long ms, String... names) throws InterruptedException {
        Set<String> want = new HashSet<>(Arrays.asList(names));
        want.add("error");
        long end = System.currentTimeMillis() + ms;
        while (true) {
            long left = end - System.currentTimeMillis();
            if (left <= 0) return null;
            JSONObject e = events.poll(left, TimeUnit.MILLISECONDS);
            if (e == null) return null;
            String ev = e.optString("event");
            if (want.contains(ev)) return e;
            if ("warn".equals(ev)) Bus.log("bot: " + e.optString("msg"));
        }
    }
}
