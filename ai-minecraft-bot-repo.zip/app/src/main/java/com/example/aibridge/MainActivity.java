package com.example.aibridge;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** One screen: AI link + key + model, goal, Start/Stop, status, log, and an EN/TH switch. */
public class MainActivity extends Activity {
    private EditText link, key, model, goal;
    private TextView status, logView;
    private Button toggle;
    private ScrollView logScroll;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        I18n.th = Prefs.lang(this);
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        build();
    }

    @Override protected void onResume() {
        super.onResume();
        Bus.listener = new Bus.Listener() { public void changed() { refresh(); } };
        refresh();
    }

    @Override protected void onPause() {
        Bus.listener = null;
        saveFields();
        super.onPause();
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(13);
        t.setPadding(0, dp(12), 0, dp(2));
        return t;
    }

    private EditText field(String value, String hint, int inputType, boolean multi) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setHint(hint);
        e.setInputType(inputType | (multi ? InputType.TYPE_TEXT_FLAG_MULTI_LINE : 0));
        e.setSingleLine(!multi);
        if (multi) e.setMinLines(2);
        return e;
    }

    private void build() {
        ScrollView root = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(16), dp(16), dp(24));
        root.addView(col);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText(I18n.t("title"));
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        head.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        Button lang = new Button(this);
        lang.setText(I18n.t("lang_btn"));
        lang.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                saveFields();
                I18n.th = !I18n.th;
                Prefs.setLang(MainActivity.this, I18n.th);
                build();
                refresh();
            }
        });
        head.addView(lang);
        col.addView(head);

        col.addView(label(I18n.t("api_link")));
        link = field(Prefs.get(this, "link", ""), I18n.t("api_link_hint"), InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI, false);
        col.addView(link);

        col.addView(label(I18n.t("api_key")));
        key = field(Prefs.get(this, "key", ""), "sk-...", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD, false);
        col.addView(key);

        col.addView(label(I18n.t("model")));
        model = field(Prefs.get(this, "model", ""), I18n.t("model_hint"), InputType.TYPE_CLASS_TEXT, false);
        col.addView(model);

        col.addView(label(I18n.t("goal")));
        goal = field(Prefs.get(this, "goal", I18n.t("goal_default")), "", InputType.TYPE_CLASS_TEXT, true);
        col.addView(goal);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(16), 0, 0);
        toggle = new Button(this);
        toggle.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { onToggle(); } });
        row.addView(toggle, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        Button upd = new Button(this);
        upd.setText(I18n.t("save_goal"));
        upd.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { saveFields(); Toast.makeText(MainActivity.this, "OK", Toast.LENGTH_SHORT).show(); }
        });
        row.addView(upd, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        col.addView(row);

        status = new TextView(this);
        status.setTextSize(15);
        status.setPadding(0, dp(14), 0, 0);
        col.addView(status);

        TextView how = new TextView(this);
        how.setText(I18n.t("how"));
        how.setTextSize(13);
        how.setPadding(0, dp(10), 0, 0);
        col.addView(how);

        col.addView(label(I18n.t("log")));
        logScroll = new ScrollView(this);
        logView = new TextView(this);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextSize(11);
        logView.setTextIsSelectable(true);
        logScroll.addView(logView);
        col.addView(logScroll, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(260)));

        setContentView(root);
    }

    private void saveFields() {
        if (link == null) return;
        Prefs.set(this, "link", link.getText().toString().trim());
        Prefs.set(this, "key", key.getText().toString().trim());
        Prefs.set(this, "model", model.getText().toString().trim());
        Prefs.set(this, "goal", goal.getText().toString().trim());
    }

    private void onToggle() {
        if (Bus.running) {
            stopService(new Intent(this, BotService.class));
        } else {
            saveFields();
            if (link.getText().toString().trim().isEmpty() || key.getText().toString().trim().isEmpty() || model.getText().toString().trim().isEmpty()) {
                Toast.makeText(this, I18n.t("need_fields"), Toast.LENGTH_LONG).show();
                return;
            }
            startForegroundService(new Intent(this, BotService.class));
        }
        refresh();
    }

    private void refresh() {
        if (status == null) return;
        toggle.setText(I18n.t(Bus.running ? "stop" : "start"));
        status.setText(I18n.t("st_ai") + I18n.t(Bus.running ? "running" : "stopped") + "\n"
                + I18n.t("st_mc") + I18n.t(Bus.mc ? "connected" : "waiting"));
        logView.setText(Bus.text());
        logScroll.post(new Runnable() { public void run() { logScroll.fullScroll(View.FOCUS_DOWN); } });
    }
}
