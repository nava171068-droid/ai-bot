package com.example.aibridge;

import android.content.Context;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

/**
 * The AI loop: observe -> ask the LLM (OpenAI-compatible /chat/completions with tools) -> run the chosen tools in the game -> repeat.
 * Each request is stateless: goal + last actions + last scan + current observation.
 */
final class Brain implements Runnable {
    volatile boolean stop = false;

    private final Context ctx;
    private final WsHub hub;
    private final OkHttpClient http = new OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(90, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build();
    private static final MediaType JSON_TYPE = MediaType.parse("application/json; charset=utf-8");
    private final ArrayList<String> recent = new ArrayList<>();
    private String lastData = "";
    private int lastDataAge = 0;
    private long pendingSleep = 0;
    private String lastDanger = "";      // newest {"event":"danger"} from the bot (lava / cliff ahead, it stopped walking)
    private int dangerAge = 99;
    private String plan = "";            // the AI's own notebook (plan / notes), kept between requests
    private boolean abortBatch = false;  // set when a danger / death event shows up: stop the rest of the queue
    private static final int MAX_BATCH = 12;
    private static final String CMD = "scriptevent ai:cmd ";
    private static final JSONArray TOOLS = buildTools();

    Brain(Context c, WsHub h) {
        this.ctx = c;
        this.hub = h;
    }

    @Override public void run() {
        try {
            loop();
        } catch (InterruptedException ignored) {
        } catch (Throwable t) {
            Bus.log("AI loop crashed: " + t);
        }
    }

    private void loop() throws Exception {
        boolean ready = false;
        while (!stop) {
            if (!hub.connected()) { ready = false; Thread.sleep(500); continue; }
            if (!ready) {
                hub.send(CMD + "spawn");      // the bot has to exist first: it is also the add-on's voice (transport "bot")
                Thread.sleep(8000);
                ready = probe() && ensureBot();
                if (!ready) { Thread.sleep(5000); continue; }
            }
            if (!step()) ready = false;
            Thread.sleep(300);
        }
    }

    // ---------------------------------------------------------------- connection checks
    /** Finds a way for the add-on's lines to reach us: chat, then /say, then /tellraw. */
    private boolean probe() throws Exception {
        String[] modes = {"bot", "chat", "say", "tellraw"};
        for (int i = 0; i < modes.length && !stop; i++) {
            hub.send(CMD + "transport " + modes[i]); Thread.sleep(600);
            hub.events.clear();
            hub.send(CMD + "ping");
            JSONObject e = hub.await(3000, "pong");
            if (e != null && "pong".equals(e.optString("event"))) {
                Bus.log(I18n.t("log_link_ok") + modes[i]);
                return true;
            }
        }
        Bus.log(I18n.t("log_no_reply"));
        return false;
    }

    private boolean ensureBot() throws Exception {
        for (int i = 0; i < 15 && !stop; i++) {
            hub.events.clear();
            hub.send(CMD + "status");
            JSONObject s = hub.await(3000, "status");
            if (s != null && s.optBoolean("alive")) { Bus.log(I18n.t("log_bot_ready")); return true; }
            if (i == 0 || i == 6) { Bus.log(I18n.t("log_bot_wait")); hub.send(CMD + "spawn"); }
            Thread.sleep(3000);
        }
        Bus.log(I18n.t("log_bot_fail"));
        return false;
    }

    // ---------------------------------------------------------------- one thinking step
    private boolean step() throws Exception {
        pendingSleep = 0;
        if (++lastDataAge > 3) lastData = "";   // old scans describe blocks that may be gone now
        dangerAge++;
        for (JSONObject ev : hub.events) {       // danger events that arrived while buttons were held
            String en = ev.optString("event");
            if ("danger".equals(en)) { lastDanger = "the bot stopped itself, do NOT walk that way: " + trunc(ev.toString(), 200); dangerAge = 0; }
            else if ("died".equals(en)) { lastDanger = "YOU DIED (lava / fall / mob?). Be more careful and check 'around' before walking."; dangerAge = 0; }
            else if ("respawned".equals(en)) { lastDanger = "you respawned next to a player; your inventory is empty, plan again."; dangerAge = 0; }
        }
        hub.events.clear();
        hub.send(CMD + "obs");
        JSONObject obs = hub.await(8000, "obs");
        if (obs == null) { Bus.log("no observation (timeout)"); return true; }
        if ("error".equals(obs.optString("event"))) { Bus.log("bot: " + obs.optString("msg")); return false; }

        JSONObject msg;
        try {
            msg = askLlm(obs);
        } catch (Exception e) {
            Bus.log(I18n.t("log_http") + e.getMessage());
            Thread.sleep(6000);
            return true;
        }
        if (msg == null) return true;

        if (!msg.isNull("content")) {
            String c = msg.optString("content", "").trim();
            if (!c.isEmpty()) Bus.log("AI: " + trunc(c, 200));
        }
        JSONArray calls = msg.optJSONArray("tool_calls");
        if (calls == null || calls.length() == 0) { Bus.log("AI answered without any tool call (nothing to do)"); Thread.sleep(2000); return true; }
        abortBatch = false;
        for (int i = 0; i < Math.min(MAX_BATCH, calls.length()) && !stop; i++) {
            JSONObject fn = calls.getJSONObject(i).optJSONObject("function");
            if (fn == null) continue;
            String name = fn.optString("name");
            JSONObject args;
            try { args = new JSONObject(fn.optString("arguments", "{}")); } catch (Exception e) { args = new JSONObject(); }
            String result = execute(name, args);
            String line = name + " " + compactArgs(args) + " -> " + result;
            Bus.log(line);
            recent.add(line);
            while (recent.size() > 20) recent.remove(0);
            if (abortBatch) { Bus.log("queue stopped: danger"); break; }
            if (isFailure(result)) {
                String skipped = (i + 1 < calls.length()) ? " (rest of the queue skipped)" : "";
                recent.add("queue stopped after a failed step" + skipped);
                break;
            }
        }
        if (pendingSleep > 0 && !stop) Thread.sleep(pendingSleep);   // let the held buttons run
        return true;
    }

    // ---------------------------------------------------------------- tools -> game commands
    private String execute(String name, JSONObject a) throws Exception {
        switch (name) {
            case "plan": {
                String t = a.optString("text", "").replaceAll("[\\r\\n]+", " ").trim();
                plan = t.length() > 1200 ? t.substring(0, 1200) : t;
                return "plan saved";
            }
            case "chop_tree": {
                int bx = (int) Math.floor(a.optDouble("x", 0)), by = (int) Math.floor(a.optDouble("y", 0)), bz = (int) Math.floor(a.optDouble("z", 0));
                return chopTree(bx, by, bz);
            }
            case "wait": {
                double s = Math.max(1, Math.min(10, a.optDouble("seconds", 2)));
                Thread.sleep((long) (s * 1000));
                return "waited";
            }
            case "scan": {
                String f = safe(a.optString("filter", ""));
                return call("scan " + clamp(a, "radius", 6, 1, 12) + (f.isEmpty() ? "" : " " + f), 10000, "scan", "find");
            }
            case "find":
                return call("find " + safe(a.optString("block", "log")) + " " + clamp(a, "radius", 10, 1, 12), 10000, "find");
            case "inventory":
            case "backpack":
                return call("backpack", 5000, "backpack");
            case "hold_item": {
                String it = safe(a.optString("item", a.has("slot") ? String.valueOf(a.optInt("slot")) : ""));
                if (it.isEmpty()) return "need item name or slot";
                return call("equip " + it, 5000, "ok");
            }
            case "walk_to":
                return call("walkto " + xyz(a), 55000, "done");
            case "swim_to_shore": {
                if (a.has("x") && a.has("y") && a.has("z")) return call("swim " + xyz(a), 45000, "done");
                return call("swim", 45000, "done");
            }
            case "pickup_items": {
                String f = safe(a.optString("item", ""));
                return call("pickup " + clamp(a, "radius", 10, 2, 24) + (f.isEmpty() ? "" : " " + f), 45000, "done");
            }
            case "mine_block":
                return call("mineat " + xyz(a), 50000, "done");
            case "look":   // face the centre of a block
                return call("look " + (Math.floor(a.optDouble("x", 0)) + 0.5) + " " + (Math.floor(a.optDouble("y", 0)) + 0.5) + " " + (Math.floor(a.optDouble("z", 0)) + 0.5), 5000, "ok");
            case "turn":
                return call("turn " + clamp(a, "yaw", 0, -180, 180) + " " + clamp(a, "pitch", 0, -90, 90), 5000, "ok");
            case "hold": {
                String b = safe(a.optString("button", ""));
                double s = Math.max(0.2, Math.min(8, a.optDouble("seconds", 1)));
                String r = call("hold " + b + " " + s, 5000, "ok");
                if (!r.equals("ok")) return r;
                pendingSleep = Math.max(pendingSleep, (long) (s * 1000) + 300);
                return "holding " + b + " for " + s + "s";
            }
            case "release": {
                String b = safe(a.optString("button", ""));
                return call("release " + (b.isEmpty() ? "all" : b), 5000, "ok");
            }
            case "tap":
                return call("tap " + safe(a.optString("button", "")), 5000, "ok");
            case "select_slot":
                return call("slot " + clamp(a, "slot", 0, 0, 8), 5000, "ok");
            case "say": {
                String t = a.optString("text", "").replaceAll("[\\r\\n]+", " ").trim();
                if (t.startsWith("/")) t = t.substring(1);
                if (t.length() > 200) t = t.substring(0, 200);
                if (t.isEmpty()) return "empty text";
                return call("say " + t, 5000, "ok");
            }
            default:
                return "unknown tool";
        }
    }

    private static boolean isFailure(String r) {
        return r.startsWith("failed") || r.startsWith("error") || r.startsWith("no reply") || r.equals("not connected") || r.equals("unknown tool");
    }

    /** Breaks every log of one tree, lowest first, in a single tool call (no LLM round trip between blocks). */
    private String chopTree(int bx, int by, int bz) throws Exception {
        hub.events.clear();
        if (!hub.send(CMD + "find log 6")) return "not connected";
        JSONObject f = hub.await(10000, "find");
        if (f == null) return "no reply (timeout)";
        if ("error".equals(f.optString("event"))) return "error: " + f.optString("msg");
        JSONArray hits = f.optJSONArray("hits");
        ArrayList<int[]> col = new ArrayList<>();
        if (hits != null) for (int i = 0; i < hits.length(); i++) {
            JSONArray h = hits.optJSONArray(i);
            if (h == null) continue;
            int x = h.optInt(0), y = h.optInt(1), z = h.optInt(2);
            if (x == bx && z == bz && y >= by) col.add(new int[]{x, y, z});
        }
        if (col.isEmpty()) col.add(new int[]{bx, by, bz});
        col.sort((p, q) -> Integer.compare(p[1], q[1]));
        int broken = 0;
        String last = "";
        for (int[] c : col) {
            if (stop) break;
            String r = call("mineat " + c[0] + " " + c[1] + " " + c[2], 50000, "done");
            last = r;
            if (!r.startsWith("done")) break;
            broken++;
            if (abortBatch) break;
        }
        return (broken > 0 ? "done: chopped " + broken + " log(s)" : "failed: " + last);
    }

    private String call(String command, long timeoutMs, String... names) throws Exception {
        for (JSONObject ev : hub.events) {   // do not lose danger / death events that arrived while the bot was busy
            String en = ev.optString("event");
            if ("danger".equals(en)) { lastDanger = "the bot stopped itself, do NOT walk that way: " + trunc(ev.toString(), 200); dangerAge = 0; abortBatch = true; }
            else if ("died".equals(en)) { lastDanger = "YOU DIED. Be more careful and check 'around' before walking."; dangerAge = 0; abortBatch = true; }
        }
        hub.events.clear();
        if (!hub.send(CMD + command)) return "not connected";
        JSONObject e = hub.await(timeoutMs, names);
        if (e == null) return "no reply (timeout)";
        String ev = e.optString("event");
        if ("error".equals(ev)) return "error: " + e.optString("msg");
        if ("scan".equals(ev) || "find".equals(ev) || "inv".equals(ev) || "backpack".equals(ev)) { lastData = trunc(e.toString(), 3000); lastDataAge = 0; return "ok (data below)"; }
        if ("done".equals(ev)) return (e.optBoolean("ok") ? "done: " : "failed: ") + e.optString("msg");
        if ("ok".equals(ev) && e.has("msg")) return "ok: " + e.optString("msg");
        return "ok";
    }

    private static String xyz(JSONObject a) {
        return (int) Math.floor(a.optDouble("x", 0)) + " " + (int) Math.floor(a.optDouble("y", 0)) + " " + (int) Math.floor(a.optDouble("z", 0));
    }

    private static int clamp(JSONObject a, String k, int def, int lo, int hi) {
        return (int) Math.max(lo, Math.min(hi, Math.round(a.optDouble(k, def))));
    }

    private static String safe(String s) {
        s = s.replaceAll("[^A-Za-z0-9_:.\\-]", "");
        return s.length() > 40 ? s.substring(0, 40) : s;
    }

    private static String trunc(String s, int n) { return s.length() > n ? s.substring(0, n) + "..." : s; }

    private static String compactArgs(JSONObject a) {
        String s = a.toString();
        return s.equals("{}") ? "" : s;
    }

    // ---------------------------------------------------------------- LLM
    private JSONObject askLlm(JSONObject obs) throws Exception {
        String base = Prefs.get(ctx, "link", "").trim();
        String key = Prefs.get(ctx, "key", "").trim();
        String model = Prefs.get(ctx, "model", "").trim();
        String goal = Prefs.get(ctx, "goal", I18n.en("goal_default")).trim();
        String url = base.replaceAll("/+$", "");
        if (!url.endsWith("/chat/completions")) url += "/chat/completions";

        StringBuilder u = new StringBuilder();
        u.append("GOAL: ").append(goal).append("\n\nYOUR PLAN / NOTES (written by you earlier with the plan tool):\n").append(plan.isEmpty() ? "(empty - write a plan first)" : plan).append("\n\nRECENT ACTIONS (oldest first):\n");
        if (recent.isEmpty()) u.append("(none yet)\n");
        for (String r : recent) u.append("- ").append(r).append('\n');
        if (!lastData.isEmpty()) u.append("\nLAST SCAN/INVENTORY DATA (about " + lastDataAge + " steps old, blocks may have changed):\n").append(lastData).append('\n');
        if (dangerAge <= 2 && !lastDanger.isEmpty()) u.append("\nNOTICE from the bot: ").append(lastDanger).append('\n');
        u.append("\nCURRENT OBSERVATION:\n").append(obs.toString());

        String system = "You are the brain of a Minecraft Bedrock player named AIBot. You act ONLY by calling tools.\n"
                + "SEE: scan / find list nearby blocks with positions; the observation gives pos, eye, yaw_pitch, 'look' (the block your crosshair is on, with its position), held buttons, nearby entities.\n"
                + "ACT: you press buttons like a real player. hold(button, seconds) keeps a button down and releases it by itself. "
                + "Buttons: forward, back, left, right, jump, sneak, sprint, mine (keep breaking the block your crosshair is on), attack (keep hitting the mob you look at). "
                + "tap(button) for jump/use/attack once. turn(yaw,pitch) rotates by degrees. look(x,y,z) turns to face a block. release stops buttons.\n"
                + "SHORTCUTS (they press the buttons for you): walk_to(x,y,z) and mine_block(x,y,z). Prefer them for 'go there' and 'break that block'; use raw buttons for fine control.\n"
                + "Rules:\n"
                + "1) QUEUE: you may call up to 12 tools in ONE turn. They run one after another, and the queue stops at the first failure or danger, then you are asked again. Each turn costs several seconds of thinking, so plan ahead and queue many steps (e.g. walk_to, chop_tree, walk_to, chop_tree, backpack). Do not wait for a result you do not need.\n"
                + "1b) PLAN: call plan(text) first to write your goal and numbered steps, and update it when you finish a step. It is shown to you every turn, so you never need to re-discover things. Do not repeat find/scan if LAST SCAN data already answers it.\n"
                + "2) Walking goes where you face (yaw only). To go to a block: look at it, hold forward (about 4 blocks per second), jump if something blocks you.\n"
                + "3) chop_tree(x,y,z) breaks the whole trunk above the lowest log in one call: prefer it for wood. To break a block: call mine_block(x,y,z) - it walks next to the block and breaks it by itself, wait for its result (done: broken). Do NOT repeat the same call if it says done. Only use hold mine if mine_block fails. Mine the LOWEST block of a tree first.\n"
                + "4) Coordinates are integers (x east, y up, z south).\n"
                + "5) Never attack players and never destroy builds you did not make.\n"
                + "6) The bot is in survival: watch hp and hostile mobs. If stuck or idle, call wait.\n"
                + "7) The observation has 'below' (block under your feet) and 'around' (f=front, b=back, l=left, r=right: ok, or lava@N / drop@N / hurt:<block>@N = hazard N blocks away). Never walk toward a side that is not ok; turn to a side that is ok. The bot also refuses to walk into lava or off a cliff by itself and reports a 'danger' event.\n"
                + "8) If the observation has 'water' you are in water (head_under = your head is under it, air = breath left). Call swim_to_shore right away, do nothing else until you are out. 'shore' tells where the nearest dry ground is. The bot also swims out by itself after ~3 s ('auto_swim' event).\n"
                + "9) BACKPACK: the observation shows 'hand' (the item in your right hand). Call backpack to see all items, then hold_item(item) before using one: an axe/pickaxe before mining, a sword before fighting, a block before placing it.\n"
                + "10) DROPS: after mine_block the bot picks up the drops by itself. If the observation has 'drops' (items lying around), call pickup_items to collect them.\n"
                + "11) Use say rarely, short, in " + (I18n.th ? "Thai" : "English") + ".";

        JSONArray messages = new JSONArray();
        messages.put(new JSONObject().put("role", "system").put("content", system));
        messages.put(new JSONObject().put("role", "user").put("content", u.toString()));
        JSONObject body = new JSONObject();
        body.put("model", model);
        body.put("temperature", 0.3);
        body.put("messages", messages);
        body.put("tools", TOOLS);
        body.put("tool_choice", "auto");

        Request req = new Request.Builder()
                .url(url)
                .header("Authorization", "Bearer " + key)
                .post(RequestBody.create(body.toString(), JSON_TYPE))
                .build();
        try (Response r = http.newCall(req).execute()) {
            String s = r.body() != null ? r.body().string() : "";
            if (!r.isSuccessful()) throw new Exception("HTTP " + r.code() + " " + trunc(s, 300));
            JSONObject j = new JSONObject(s);
            JSONArray ch = j.optJSONArray("choices");
            if (ch == null || ch.length() == 0) throw new Exception("no choices: " + trunc(s, 200));
            return ch.getJSONObject(0).getJSONObject("message");
        }
    }

    // ---------------------------------------------------------------- tool schemas
    private static JSONObject tool(String name, String desc, String... params) {
        try {
            JSONObject props = new JSONObject();
            JSONArray req = new JSONArray();
            for (String p : params) {
                boolean required = p.startsWith("*");
                if (required) p = p.substring(1);
                String[] kv = p.split(":");
                props.put(kv[0], new JSONObject().put("type", kv[1]));
                if (required) req.put(kv[0]);
            }
            JSONObject parameters = new JSONObject().put("type", "object").put("properties", props).put("required", req);
            JSONObject fn = new JSONObject().put("name", name).put("description", desc).put("parameters", parameters);
            return new JSONObject().put("type", "function").put("function", fn);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static JSONArray buildTools() {
        JSONArray t = new JSONArray();
        t.put(tool("scan", "Summarise the blocks around the bot (type, count, nearest position). Optional filter = part of a block name.", "radius:integer", "filter:string"));
        t.put(tool("find", "List the nearest positions of a block type, e.g. block='log' or 'iron_ore'.", "*block:string", "radius:integer"));
        t.put(tool("backpack", "Open the backpack: lists everything the bot carries as [slot, item, amount] (slots 0-8 = hotbar) and what is in the right hand."));
        t.put(tool("hold_item", "Put an item from the backpack in the right hand, by item name (e.g. 'oak_log', 'pickaxe') or slot number. Items from the bag move to the hotbar.", "item:string", "slot:integer"));
        t.put(tool("walk_to", "Walk to x,z by pressing forward and jump for you (no pathfinding; goes straight, jumps when stuck). Waits until arrived or failed.", "*x:integer", "*y:integer", "*z:integer"));
        t.put(tool("mine_block", "Walk next to the block at x,y,z, look at it and hold mine until it breaks. Waits until broken or failed. Use find first to get a real position.", "*x:integer", "*y:integer", "*z:integer"));
        t.put(tool("plan", "Write or replace your notebook: goal, numbered steps, facts you found (positions). It is shown to you every turn.", "*text:string"));
        t.put(tool("chop_tree", "Break all logs of one tree trunk from the lowest log at x,y,z upward, one call. Use find log first to get the lowest log position.", "*x:integer", "*y:integer", "*z:integer"));
        t.put(tool("swim_to_shore", "Swim to the nearest shore (or to x,y,z) by pressing the swim buttons for you. Use it as soon as obs has 'water'. Waits until out of the water or failed.", "x:integer", "y:integer", "z:integer"));
        t.put(tool("pickup_items", "Walk to the dropped items nearby and pick them up (the obs field 'drops' lists them as [x,y,z,item,amount,distance]). Optional item = part of an item name. mine_block already does this after a block breaks.", "radius:integer", "item:string"));
        t.put(tool("look", "Turn to face the centre of the block at x,y,z.", "*x:integer", "*y:integer", "*z:integer"));
        t.put(tool("turn", "Rotate the view by degrees: yaw + turns right (clockwise), yaw - turns left, pitch + looks down.", "yaw:integer", "pitch:integer"));
        t.put(tool("hold", "Hold a button down for some seconds (0.2-8), it releases by itself. Buttons: forward, back, left, right, jump, sneak, sprint, mine, attack.", "*button:string", "seconds:number"));
        t.put(tool("tap", "Press a button once: jump, use or attack.", "*button:string"));
        t.put(tool("release", "Release one button, or all buttons when button is empty.", "button:string"));
        t.put(tool("select_slot", "Select hotbar slot 0-8.", "*slot:integer"));
        t.put(tool("say", "Say something in the game chat.", "*text:string"));
        t.put(tool("wait", "Do nothing for a few seconds.", "seconds:integer"));
        return t;
    }
}
