package com.example.aibridge;

import android.content.Context;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

/**
 * The AI loop: observe -> ask the LLM (OpenAI-compatible /chat/completions with tools) -> run the chosen tools in the game -> repeat.
 * Each request is stateless: goal + last actions + last scan + current observation.
 */
final class Brain implements Runnable {
    volatile boolean stop = false;

    private final Context ctx;
    private final WsHub hub;
    private final OkHttpClient http = new OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(90, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build();
    private static final MediaType JSON_TYPE = MediaType.parse("application/json; charset=utf-8");
    private final ArrayList<String> recent = new ArrayList<>();
    private String lastData = "";
    private int lastDataAge = 0;
    private long pendingSleep = 0;
    private String lastDanger = "";      // newest {"event":"danger"} from the bot (lava / cliff ahead, it stopped walking)
    private int dangerAge = 99;
    private String plan = "";            // the AI's own notebook (plan / notes), kept between requests
    private boolean abortBatch = false;  // set when a danger / death event shows up: stop the rest of the queue
    private static final int MAX_BATCH = 12;
    private int tpmLimit = 0;                                   // tokens per minute the provider allows (0 = unknown, learned from a 429)
    private final java.util.ArrayDeque<long[]> tokenLog = new java.util.ArrayDeque<>();   // {time ms, tokens} of recent requests
    private static final String CMD = "scriptevent ai:cmd ";
    private static final JSONArray TOOLS = buildTools();

    Brain(Context c, WsHub h) {
        this.ctx = c;
        this.hub = h;
    }

    @Override public void run() {
        try {
            loop();
        } catch (InterruptedException ignored) {
        } catch (Throwable t) {
            Bus.log("AI loop crashed: " + t);
        }
    }

    private void loop() throws Exception {
        boolean ready = false;
        while (!stop) {
            if (!hub.connected()) { ready = false; Thread.sleep(500); continue; }
            if (!ready) {
                hub.send(CMD + "spawn");      // the bot has to exist first: it is also the add-on's voice (transport "bot")
                Thread.sleep(8000);
                ready = probe() && ensureBot();
                if (!ready) { Thread.sleep(5000); continue; }
            }
            if (!step()) ready = false;
            Thread.sleep(60);
        }
    }

    // ---------------------------------------------------------------- connection checks
    /** Finds a way for the add-on's lines to reach us: chat, then /say, then /tellraw. */
    private boolean probe() throws Exception {
        String[] modes = {"bot", "chat", "say", "tellraw"};
        for (int i = 0; i < modes.length && !stop; i++) {
            hub.send(CMD + "transport " + modes[i]); Thread.sleep(600);
            hub.events.clear();
            hub.send(CMD + "ping");
            JSONObject e = hub.await(3000, "pong");
            if (e != null && "pong".equals(e.optString("event"))) {
                Bus.log(I18n.t("log_link_ok") + modes[i]);
                return true;
            }
        }
        Bus.log(I18n.t("log_no_reply"));
        return false;
    }

    private boolean ensureBot() throws Exception {
        for (int i = 0; i < 15 && !stop; i++) {
            hub.events.clear();
            hub.send(CMD + "status");
            JSONObject s = hub.await(3000, "status");
            if (s != null && s.optBoolean("alive")) { Bus.log(I18n.t("log_bot_ready")); return true; }
            if (i == 0 || i == 6) { Bus.log(I18n.t("log_bot_wait")); hub.send(CMD + "spawn"); }
            Thread.sleep(3000);
        }
        Bus.log(I18n.t("log_bot_fail"));
        return false;
    }

    // ---------------------------------------------------------------- one thinking step
    private boolean step() throws Exception {
        pendingSleep = 0;
        if (++lastDataAge > 3) lastData = "";   // old scans describe blocks that may be gone now
        dangerAge++;
        for (JSONObject ev : hub.notices) noteEvent(ev, false);  // reflex / danger events that arrived while we waited for something else
        hub.notices.clear();
        for (JSONObject ev : hub.events) noteEvent(ev, false);   // events that arrived while buttons were held
        hub.events.clear();
        hub.send(CMD + "obs");
        JSONObject obs = hub.await(8000, "obs");
        if (obs == null) { Bus.log("no observation (timeout)"); return true; }
        if ("error".equals(obs.optString("event"))) { Bus.log("bot: " + obs.optString("msg")); return false; }

        JSONObject msg;
        long t0 = System.currentTimeMillis();
        try {
            msg = askLlm(obs);
            Bus.log("LLM " + (System.currentTimeMillis() - t0) + " ms");
        } catch (Exception e) {
            String em = String.valueOf(e.getMessage());
            if (em.startsWith("HTTP 429")) {
                java.util.regex.Matcher lm = java.util.regex.Pattern.compile("Limit (\\d+)").matcher(em);
                if (lm.find()) tpmLimit = (int) (Integer.parseInt(lm.group(1)) * 0.85);   // learn the per-minute token limit, stay under it from now on
                java.util.regex.Matcher wm = java.util.regex.Pattern.compile("try again in ([0-9.]+)s").matcher(em);
                long w = wm.find() ? (long) (Double.parseDouble(wm.group(1)) * 1000) + 500 : 8000;
                Bus.log("rate limit (tokens/min), waiting " + (w / 1000) + " s" + (tpmLimit > 0 ? " - pacing to " + tpmLimit + " tokens/min from now" : ""));
                Thread.sleep(Math.min(w, 60000));
                return true;
            }
            Bus.log(I18n.t("log_http") + em);
            Thread.sleep(4000);
            return true;
        }
        if (msg == null) return true;

        if (!msg.isNull("content")) {
            String c = msg.optString("content", "").trim();
            if (!c.isEmpty()) Bus.log("AI: " + trunc(c, 200));
        }
        JSONArray calls = msg.optJSONArray("tool_calls");
        if (calls == null || calls.length() == 0) { Bus.log("AI answered without any tool call (nothing to do)"); Thread.sleep(2000); return true; }
        abortBatch = false;
        for (int i = 0; i < Math.min(MAX_BATCH, calls.length()) && !stop; i++) {
            JSONObject fn = calls.getJSONObject(i).optJSONObject("function");
            if (fn == null) continue;
            String name = fn.optString("name");
            JSONObject args;
            try { args = new JSONObject(fn.optString("arguments", "{}")); } catch (Exception e) { args = new JSONObject(); }
            String result = execute(name, args);
            String line = name + " " + compactArgs(args) + " -> " + result;
            Bus.log(line);
            recent.add(line);
            while (recent.size() > 8) recent.remove(0);
            if (abortBatch) { Bus.log("queue stopped: danger"); break; }
            if (isFailure(result)) {
                String skipped = (i + 1 < calls.length()) ? " (rest of the queue skipped)" : "";
                recent.add("queue stopped after a failed step" + skipped);
                break;
            }
        }
        if (pendingSleep > 0 && !stop) Thread.sleep(pendingSleep);   // let the held buttons run
        return true;
    }

    // ---------------------------------------------------------------- tools -> game commands
    private String execute(String name, JSONObject a) throws Exception {
        switch (name) {
            case "plan": {
                String t = a.optString("text", "").replaceAll("[\\r\\n]+", " ").trim();
                plan = t.length() > 1200 ? t.substring(0, 1200) : t;
                return "plan saved";
            }
            case "chop_tree": {
                int bx = (int) Math.floor(a.optDouble("x", 0)), by = (int) Math.floor(a.optDouble("y", 0)), bz = (int) Math.floor(a.optDouble("z", 0));
                return chopTree(bx, by, bz);
            }
            case "wait": {
                double s = Math.max(1, Math.min(10, a.optDouble("seconds", 2)));
                Thread.sleep((long) (s * 1000));
                return "waited";
            }
            case "scan": {
                String f = safe(a.optString("filter", ""));
                return call("scan " + clamp(a, "radius", 6, 1, 12) + (f.isEmpty() ? "" : " " + f), 10000, "scan", "find");
            }
            case "collect": {
                String b = safe(a.optString("block", "log"));
                int n = clamp(a, "count", 1, 1, 32);
                return call("collect " + b + " " + n, 40000L * n + 20000, "done");
            }
            case "fight": {
                String m = safe(a.optString("mob", ""));
                return call("attack" + (m.isEmpty() ? "" : " " + m), 65000, "done");
            }
            case "find":
                return call("find " + safe(a.optString("block", "log")) + " " + clamp(a, "radius", 10, 1, 12), 10000, "find");
            case "inventory":
            case "backpack":
                return call("backpack", 5000, "backpack");
            case "hold_item": {
                String it = safe(a.optString("item", a.has("slot") ? String.valueOf(a.optInt("slot")) : ""));
                if (it.isEmpty()) return "need item name or slot";
                return call("equip " + it, 5000, "ok");
            }
            case "walk_to":
                return call("walkto " + xyz(a), 55000, "done");
            case "swim_to_shore": {
                if (a.has("x") && a.has("y") && a.has("z")) return call("swim " + xyz(a), 45000, "done");
                return call("swim", 45000, "done");
            }
            case "pickup_items": {
                String f = safe(a.optString("item", ""));
                return call("pickup " + clamp(a, "radius", 10, 2, 24) + (f.isEmpty() ? "" : " " + f), 45000, "done");
            }
            case "mine_block":
                return call("mineat " + xyz(a), 50000, "done");
            case "look":   // face the centre of a block
                return call("look " + (Math.floor(a.optDouble("x", 0)) + 0.5) + " " + (Math.floor(a.optDouble("y", 0)) + 0.5) + " " + (Math.floor(a.optDouble("z", 0)) + 0.5), 5000, "ok");
            case "turn":
                return call("turn " + clamp(a, "yaw", 0, -180, 180) + " " + clamp(a, "pitch", 0, -90, 90), 5000, "ok");
            case "hold": {
                String b = safe(a.optString("button", ""));
                double s = Math.max(0.2, Math.min(8, a.optDouble("seconds", 1)));
                String r = call("hold " + b + " " + s, 5000, "ok");
                if (!r.equals("ok")) return r;
                pendingSleep = Math.max(pendingSleep, (long) (s * 1000) + 300);
                return "holding " + b + " for " + s + "s";
            }
            case "release": {
                String b = safe(a.optString("button", ""));
                return call("release " + (b.isEmpty() ? "all" : b), 5000, "ok");
            }
            case "tap":
                return call("tap " + safe(a.optString("button", "")), 5000, "ok");
            case "select_slot":
                return call("slot " + clamp(a, "slot", 0, 0, 8), 5000, "ok");
            case "say": {
                String t = a.optString("text", "").replaceAll("[\\r\\n]+", " ").trim();
                if (t.startsWith("/")) t = t.substring(1);
                if (t.length() > 200) t = t.substring(0, 200);
                if (t.isEmpty()) return "empty text";
                return call("say " + t, 5000, "ok");
            }
            default:
                return "unknown tool";
        }
    }

    /** Turns an event the add-on sent by itself (danger, death, reflex) into a notice for the AI. */
    private void noteEvent(JSONObject ev, boolean abort) {
        String en = ev.optString("event");
        if ("danger".equals(en)) { lastDanger = "the bot stopped itself, do NOT walk that way: " + trunc(ev.toString(), 200); dangerAge = 0; if (abort) abortBatch = true; }
        else if ("died".equals(en)) { lastDanger = "YOU DIED (lava / fall / mob?). Be more careful and check 'around' before walking."; dangerAge = 0; if (abort) abortBatch = true; }
        else if ("respawned".equals(en)) { lastDanger = "you respawned next to a player; your inventory is empty, plan again."; dangerAge = 0; }
        else if ("reflex".equals(en)) {
            String w = ev.optString("what");
            String t;
            if ("fight_start".equals(w)) { t = "REFLEX: a " + ev.optString("mob") + " came close, your body is fighting it by itself (hp " + ev.opt("hp") + "). Your queued steps were dropped."; if (abort) abortBatch = true; }
            else if ("fight_end".equals(w)) t = "REFLEX: the fight is over (hp " + ev.opt("hp") + "). Continue your plan.";
            else if ("eat".equals(w)) t = "REFLEX: hp was low (" + ev.opt("hp") + "), you are eating " + ev.optString("item") + ".";
            else if ("hurt_no_food".equals(w)) t = "REFLEX: hp is low (" + ev.opt("hp") + ") and you have NO food. Get food (animals) or stay safe.";
            else t = trunc(ev.toString(), 200);
            lastDanger = t; dangerAge = 0;
            Bus.log(t);
        }
    }

    private static boolean isFailure(String r) {
        return r.startsWith("failed") || r.startsWith("error") || r.startsWith("no reply") || r.equals("not connected") || r.equals("unknown tool");
    }

    /** Breaks every log of one tree, lowest first, in a single tool call (no LLM round trip between blocks). */
    private String chopTree(int bx, int by, int bz) throws Exception {
        hub.events.clear();
        if (!hub.send(CMD + "find log 6")) return "not connected";
        JSONObject f = hub.await(10000, "find");
        if (f == null) return "no reply (timeout)";
        if ("error".equals(f.optString("event"))) return "error: " + f.optString("msg");
        JSONArray hits = f.optJSONArray("hits");
        ArrayList<int[]> col = new ArrayList<>();
        if (hits != null) for (int i = 0; i < hits.length(); i++) {
            JSONArray h = hits.optJSONArray(i);
            if (h == null) continue;
            int x = h.optInt(0), y = h.optInt(1), z = h.optInt(2);
            if (x == bx && z == bz && y >= by) col.add(new int[]{x, y, z});
        }
        if (col.isEmpty()) col.add(new int[]{bx, by, bz});
        col.sort((p, q) -> Integer.compare(p[1], q[1]));
        int broken = 0;
        String last = "";
        for (int[] c : col) {
            if (stop) break;
            String r = call("mineat " + c[0] + " " + c[1] + " " + c[2], 50000, "done");
            last = r;
            if (!r.startsWith("done")) break;
            broken++;
            if (abortBatch) break;
        }
        return (broken > 0 ? "done: chopped " + broken + " log(s)" : "failed: " + last);
    }

    private String call(String command, long timeoutMs, String... names) throws Exception {
        for (JSONObject ev : hub.notices) noteEvent(ev, true);
        hub.notices.clear();
        for (JSONObject ev : hub.events) noteEvent(ev, true);   // do not lose danger / death / reflex events that arrived while the bot was busy
        hub.events.clear();
        if (!hub.send(CMD + command)) return "not connected";
        JSONObject e = hub.await(timeoutMs, names);
        if (e == null) return "no reply (timeout)";
        String ev = e.optString("event");
        if ("error".equals(ev)) return "error: " + e.optString("msg");
        if ("scan".equals(ev) || "find".equals(ev) || "inv".equals(ev) || "backpack".equals(ev)) { lastData = trunc(e.toString(), 1200); lastDataAge = 0; return "ok (data below)"; }
        if ("done".equals(ev)) return (e.optBoolean("ok") ? "done: " : "failed: ") + e.optString("msg");
        if ("ok".equals(ev) && e.has("msg")) return "ok: " + e.optString("msg");
        return "ok";
    }

    private static String xyz(JSONObject a) {
        return (int) Math.floor(a.optDouble("x", 0)) + " " + (int) Math.floor(a.optDouble("y", 0)) + " " + (int) Math.floor(a.optDouble("z", 0));
    }

    private static int clamp(JSONObject a, String k, int def, int lo, int hi) {
        return (int) Math.max(lo, Math.min(hi, Math.round(a.optDouble(k, def))));
    }

    private static String safe(String s) {
        s = s.replaceAll("[^A-Za-z0-9_:.\\-]", "");
        return s.length() > 40 ? s.substring(0, 40) : s;
    }

    private static String trunc(String s, int n) { return s.length() > n ? s.substring(0, n) + "..." : s; }

    private static String compactArgs(JSONObject a) {
        String s = a.toString();
        return s.equals("{}") ? "" : s;
    }

    // ---------------------------------------------------------------- LLM
    private JSONObject askLlm(JSONObject obs) throws Exception {
        String base = Prefs.get(ctx, "link", "").trim();
        String key = Prefs.get(ctx, "key", "").trim();
        String model = Prefs.get(ctx, "model", "").trim();
        String goal = Prefs.get(ctx, "goal", I18n.en("goal_default")).trim();
        String url = base.replaceAll("/+$", "");
        if (!url.endsWith("/chat/completions")) url += "/chat/completions";

        StringBuilder u = new StringBuilder();
        u.append("GOAL: ").append(goal).append("\n\nYOUR PLAN / NOTES (written by you earlier with the plan tool):\n").append(plan.isEmpty() ? "(empty - write a plan first)" : plan).append("\n\nRECENT ACTIONS (oldest first):\n");
        if (recent.isEmpty()) u.append("(none yet)\n");
        for (String r : recent) u.append("- ").append(r).append('\n');
        if (!lastData.isEmpty()) u.append("\nLAST SCAN/INVENTORY DATA (about " + lastDataAge + " steps old, blocks may have changed):\n").append(lastData).append('\n');
        if (dangerAge <= 2 && !lastDanger.isEmpty()) u.append("\nNOTICE from the bot: ").append(lastDanger).append('\n');
        u.append("\nCURRENT OBSERVATION:\n").append(obs.toString());

        String system = "You are AIBot, a Minecraft Bedrock survival player. Act ONLY by calling tools; up to 12 per turn, run in order, the queue stops at a failure. Each turn is slow and costs tokens, so queue many steps.\n"
                + "Start with plan(text): goal + numbered steps; it is shown to you every turn. Do not repeat find/scan if LAST SCAN data already answers.\n"
                + "Obs: pos, hp, hand, inv, near (entities), drops, below, around (f/b/l/r: ok or lava@N / drop@N = hazard N blocks away; never walk toward a side that is not ok), water (call swim_to_shore at once).\n"
                + "GATHER: collect(block,count) does find + walk + mine + pickup in one call (e.g. log, iron_ore, stone). It only sees 14 blocks around you. If it or find reports nothing (find/scan radius max is 12), EXPLORE: walk_to a point 25-30 blocks away (try a different direction each time, keep a list of tried directions in plan), then collect again. Never repeat a find that already found nothing at the same spot.\n"
                + "Before mining hold the right tool (hold_item 'axe'/'pickaxe'); before fighting a sword. Coordinates are integers (x east, y up, z south). Never attack players or destroy builds you did not make.\n"
                + "REFLEXES: your body already fights monsters that come close and eats when hp is low; you get a REFLEX notice. Afterwards just continue the plan. You decide the big things: what to gather, where to go, build, retreat, help the player, what to say.\n"
                + "Say (rarely, short, in " + (I18n.th ? "Thai" : "English") + ") only to talk to the player. If idle or stuck call wait.";

        JSONArray messages = new JSONArray();
        messages.put(new JSONObject().put("role", "system").put("content", system));
        messages.put(new JSONObject().put("role", "user").put("content", u.toString()));
        JSONObject body = new JSONObject();
        body.put("model", model);
        body.put("temperature", 0.3);
        body.put("messages", messages);
        body.put("tools", TOOLS);
        body.put("tool_choice", "auto");

        paceTokens();
        Request req = new Request.Builder()
                .url(url)
                .header("Authorization", "Bearer " + key)
                .post(RequestBody.create(body.toString(), JSON_TYPE))
                .build();
        try (Response r = http.newCall(req).execute()) {
            String s = r.body() != null ? r.body().string() : "";
            if (!r.isSuccessful()) throw new Exception("HTTP " + r.code() + " " + trunc(s, 300));
            JSONObject j = new JSONObject(s);
            JSONObject us = j.optJSONObject("usage");
            if (us != null) tokenLog.add(new long[]{System.currentTimeMillis(), us.optLong("total_tokens", 0)});
            JSONArray ch = j.optJSONArray("choices");
            if (ch == null || ch.length() == 0) throw new Exception("no choices: " + trunc(s, 200));
            return ch.getJSONObject(0).getJSONObject("message");
        }
    }

    /** Waits (if needed) so the tokens used in the last 60 s plus one more request stay under the provider's per-minute limit. */
    private void paceTokens() throws InterruptedException {
        if (tpmLimit <= 0) return;
        while (!stop) {
            long now = System.currentTimeMillis(), used = 0, oldest = now;
            while (!tokenLog.isEmpty() && now - tokenLog.peekFirst()[0] > 60000) tokenLog.pollFirst();
            long last = 0;
            for (long[] e : tokenLog) { used += e[1]; last = e[1]; if (e[0] < oldest) oldest = e[0]; }
            if (used + Math.max(last, 1500) <= tpmLimit) return;
            long wait = Math.max(500, 60000 - (now - oldest) + 200);
            Bus.log("pacing: waiting " + (wait / 1000) + " s for the token limit");
            Thread.sleep(Math.min(wait, 20000));
        }
    }

    // ---------------------------------------------------------------- tool schemas
    private static JSONObject tool(String name, String desc, String... params) {
        try {
            JSONObject props = new JSONObject();
            JSONArray req = new JSONArray();
            for (String p : params) {
                boolean required = p.startsWith("*");
                if (required) p = p.substring(1);
                String[] kv = p.split(":");
                props.put(kv[0], new JSONObject().put("type", kv[1]));
                if (required) req.put(kv[0]);
            }
            JSONObject parameters = new JSONObject().put("type", "object").put("properties", props).put("required", req);
            JSONObject fn = new JSONObject().put("name", name).put("description", desc).put("parameters", parameters);
            return new JSONObject().put("type", "function").put("function", fn);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static JSONArray buildTools() {
        JSONArray t = new JSONArray();
        t.put(tool("scan", "Count nearby blocks by type with nearest position. Optional filter (part of a block name). radius max 12.", "radius:integer", "filter:string"));
        t.put(tool("find", "Nearest positions of a block type (radius max 12), e.g. block=iron_ore.", "*block:string", "radius:integer"));
        t.put(tool("backpack", "List carried items [slot,item,amount] and the item in hand."));
        t.put(tool("hold_item", "Put an item in hand by name (e.g. pickaxe) or slot.", "item:string", "slot:integer"));
        t.put(tool("walk_to", "Walk straight to x,y,z (jumps when stuck, no pathfinding). Waits until arrived or failed.", "*x:integer", "*y:integer", "*z:integer"));
        t.put(tool("mine_block", "Walk to the block at x,y,z and mine it, then pick up the drops. Waits until done.", "*x:integer", "*y:integer", "*z:integer"));
        t.put(tool("plan", "Write or replace your notebook (goal, steps, facts). Shown every turn.", "*text:string"));
        t.put(tool("collect", "BEST for gathering: find nearest block of this kind (part of name: log, iron_ore, stone, sand) within 14 blocks, mine, pick up, repeat count times, in ONE call.", "*block:string", "count:integer"));
        t.put(tool("fight", "Hunt a creature on purpose (e.g. mob=cow for food). Monsters nearby are already fought automatically.", "mob:string"));
        t.put(tool("chop_tree", "Break the whole trunk above the lowest log at x,y,z.", "*x:integer", "*y:integer", "*z:integer"));
        t.put(tool("swim_to_shore", "Swim to the nearest shore (or x,y,z). Use as soon as obs has water.", "x:integer", "y:integer", "z:integer"));
        t.put(tool("pickup_items", "Walk to nearby dropped items and pick them up.", "radius:integer", "item:string"));
        t.put(tool("look", "Face the block at x,y,z.", "*x:integer", "*y:integer", "*z:integer"));
        t.put(tool("turn", "Rotate view by degrees (yaw + = right, pitch + = down).", "yaw:integer", "pitch:integer"));
        t.put(tool("hold", "Hold a button (forward, back, left, right, jump, sneak, sprint, mine, attack) for 0.2-8 s.", "*button:string", "seconds:number"));
        t.put(tool("tap", "Press jump, use or attack once.", "*button:string"));
        t.put(tool("release", "Release one button, or all if empty.", "button:string"));
        t.put(tool("select_slot", "Select hotbar slot 0-8.", "*slot:integer"));
        t.put(tool("say", "Say something in chat.", "*text:string"));
        t.put(tool("wait", "Do nothing for a few seconds.", "seconds:integer"));
        return t;
    }
}
