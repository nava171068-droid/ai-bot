package com.example.aibridge;

import android.content.Context;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

/**
 * The AI loop: observe -> ask the LLM (OpenAI-compatible /chat/completions with tools) -> run the chosen tools in the game -> repeat.
 * Each request is stateless: goal + last actions + last scan + current observation.
 */
final class Brain implements Runnable {
    volatile boolean stop = false;

    private final Context ctx;
    private final WsHub hub;
    private final OkHttpClient http = new OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(90, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build();
    private static final MediaType JSON_TYPE = MediaType.parse("application/json; charset=utf-8");
    private final ArrayList<String> recent = new ArrayList<>();
    private String lastData = "";
    private int lastDataAge = 0;
    private long pendingSleep = 0;
    private static final String CMD = "scriptevent ai:cmd ";
    private static final JSONArray TOOLS = buildTools();

    Brain(Context c, WsHub h) {
        this.ctx = c;
        this.hub = h;
    }

    @Override public void run() {
        try {
            loop();
        } catch (InterruptedException ignored) {
        } catch (Throwable t) {
            Bus.log("AI loop crashed: " + t);
        }
    }

    private void loop() throws Exception {
        boolean ready = false;
        while (!stop) {
            if (!hub.connected()) { ready = false; Thread.sleep(500); continue; }
            if (!ready) {
                hub.send(CMD + "spawn");      // the bot has to exist first: it is also the add-on's voice (transport "bot")
                Thread.sleep(8000);
                ready = probe() && ensureBot();
                if (!ready) { Thread.sleep(5000); continue; }
            }
            if (!step()) ready = false;
            Thread.sleep(1200);
        }
    }

    // ---------------------------------------------------------------- connection checks
    /** Finds a way for the add-on's lines to reach us: chat, then /say, then /tellraw. */
    private boolean probe() throws Exception {
        String[] modes = {"bot", "chat", "say", "tellraw"};
        for (int i = 0; i < modes.length && !stop; i++) {
            hub.send(CMD + "transport " + modes[i]); Thread.sleep(600);
            hub.events.clear();
            hub.send(CMD + "ping");
            JSONObject e = hub.await(3000, "pong");
            if (e != null && "pong".equals(e.optString("event"))) {
                Bus.log(I18n.t("log_link_ok") + modes[i]);
                return true;
            }
        }
        Bus.log(I18n.t("log_no_reply"));
        return false;
    }

    private boolean ensureBot() throws Exception {
        for (int i = 0; i < 15 && !stop; i++) {
            hub.events.clear();
            hub.send(CMD + "status");
            JSONObject s = hub.await(3000, "status");
            if (s != null && s.optBoolean("alive")) { Bus.log(I18n.t("log_bot_ready")); return true; }
            if (i == 0 || i == 6) { Bus.log(I18n.t("log_bot_wait")); hub.send(CMD + "spawn"); }
            Thread.sleep(3000);
        }
        Bus.log(I18n.t("log_bot_fail"));
        return false;
    }

    // ---------------------------------------------------------------- one thinking step
    private boolean step() throws Exception {
        pendingSleep = 0;
        if (++lastDataAge > 3) lastData = "";   // old scans describe blocks that may be gone now
        hub.events.clear();
        hub.send(CMD + "obs");
        JSONObject obs = hub.await(8000, "obs");
        if (obs == null) { Bus.log("no observation (timeout)"); return true; }
        if ("error".equals(obs.optString("event"))) { Bus.log("bot: " + obs.optString("msg")); return false; }

        JSONObject msg;
        try {
            msg = askLlm(obs);
        } catch (Exception e) {
            Bus.log(I18n.t("log_http") + e.getMessage());
            Thread.sleep(6000);
            return true;
        }
        if (msg == null) return true;

        if (!msg.isNull("content")) {
            String c = msg.optString("content", "").trim();
            if (!c.isEmpty()) Bus.log("AI: " + trunc(c, 200));
        }
        JSONArray calls = msg.optJSONArray("tool_calls");
        if (calls == null || calls.length() == 0) { Bus.log("AI answered without any tool call (nothing to do)"); Thread.sleep(2000); return true; }
        for (int i = 0; i < Math.min(3, calls.length()) && !stop; i++) {
            JSONObject fn = calls.getJSONObject(i).optJSONObject("function");
            if (fn == null) continue;
            String name = fn.optString("name");
            JSONObject args;
            try { args = new JSONObject(fn.optString("arguments", "{}")); } catch (Exception e) { args = new JSONObject(); }
            String result = execute(name, args);
            String line = name + " " + compactArgs(args) + " -> " + result;
            Bus.log(line);
            recent.add(line);
            while (recent.size() > 10) recent.remove(0);
        }
        if (pendingSleep > 0 && !stop) Thread.sleep(pendingSleep);   // let the held buttons run
        return true;
    }

    // ---------------------------------------------------------------- tools -> game commands
    private String execute(String name, JSONObject a) throws Exception {
        switch (name) {
            case "wait": {
                double s = Math.max(1, Math.min(10, a.optDouble("seconds", 2)));
                Thread.sleep((long) (s * 1000));
                return "waited";
            }
            case "scan": {
                String f = safe(a.optString("filter", ""));
                return call("scan " + clamp(a, "radius", 6, 1, 12) + (f.isEmpty() ? "" : " " + f), 10000, "scan", "find");
            }
            case "find":
                return call("find " + safe(a.optString("block", "log")) + " " + clamp(a, "radius", 10, 1, 12), 10000, "find");
            case "inventory":
                return call("inv", 5000, "inv");
            case "walk_to":
                return call("walkto " + xyz(a), 55000, "done");
            case "mine_block":
                return call("mineat " + xyz(a), 50000, "done");
            case "look":   // face the centre of a block
                return call("look " + (Math.floor(a.optDouble("x", 0)) + 0.5) + " " + (Math.floor(a.optDouble("y", 0)) + 0.5) + " " + (Math.floor(a.optDouble("z", 0)) + 0.5), 5000, "ok");
            case "turn":
                return call("turn " + clamp(a, "yaw", 0, -180, 180) + " " + clamp(a, "pitch", 0, -90, 90), 5000, "ok");
            case "hold": {
                String b = safe(a.optString("button", ""));
                double s = Math.max(0.2, Math.min(8, a.optDouble("seconds", 1)));
                String r = call("hold " + b + " " + s, 5000, "ok");
                if (!r.equals("ok")) return r;
                pendingSleep = Math.max(pendingSleep, (long) (s * 1000) + 300);
                return "holding " + b + " for " + s + "s";
            }
            case "release": {
                String b = safe(a.optString("button", ""));
                return call("release " + (b.isEmpty() ? "all" : b), 5000, "ok");
            }
            case "tap":
                return call("tap " + safe(a.optString("button", "")), 5000, "ok");
            case "select_slot":
                return call("slot " + clamp(a, "slot", 0, 0, 8), 5000, "ok");
            case "say": {
                String t = a.optString("text", "").replaceAll("[\\r\\n]+", " ").trim();
                if (t.startsWith("/")) t = t.substring(1);
                if (t.length() > 200) t = t.substring(0, 200);
                if (t.isEmpty()) return "empty text";
                return call("say " + t, 5000, "ok");
            }
            default:
                return "unknown tool";
        }
    }

    private String call(String command, long timeoutMs, String... names) throws Exception {
        hub.events.clear();
        if (!hub.send(CMD + command)) return "not connected";
        JSONObject e = hub.await(timeoutMs, names);
        if (e == null) return "no reply (timeout)";
        String ev = e.optString("event");
        if ("error".equals(ev)) return "error: " + e.optString("msg");
        if ("scan".equals(ev) || "find".equals(ev) || "inv".equals(ev)) { lastData = trunc(e.toString(), 3000); lastDataAge = 0; return "ok (data below)"; }
        if ("done".equals(ev)) return (e.optBoolean("ok") ? "done: " : "failed: ") + e.optString("msg");
        return "ok";
    }

    private static String xyz(JSONObject a) {
        return (int) Math.floor(a.optDouble("x", 0)) + " " + (int) Math.floor(a.optDouble("y", 0)) + " " + (int) Math.floor(a.optDouble("z", 0));
    }

    private static int clamp(JSONObject a, String k, int def, int lo, int hi) {
        return (int) Math.max(lo, Math.min(hi, Math.round(a.optDouble(k, def))));
    }

    private static String safe(String s) {
        s = s.replaceAll("[^A-Za-z0-9_:.\\-]", "");
        return s.length() > 40 ? s.substring(0, 40) : s;
    }

    private static String trunc(String s, int n) { return s.length() > n ? s.substring(0, n) + "..." : s; }

    private static String compactArgs(JSONObject a) {
        String s = a.toString();
        return s.equals("{}") ? "" : s;
    }

    // ---------------------------------------------------------------- LLM
    private JSONObject askLlm(JSONObject obs) throws Exception {
        String base = Prefs.get(ctx, "link", "").trim();
        String key = Prefs.get(ctx, "key", "").trim();
        String model = Prefs.get(ctx, "model", "").trim();
        String goal = Prefs.get(ctx, "goal", I18n.en("goal_default")).trim();
        String url = base.replaceAll("/+$", "");
        if (!url.endsWith("/chat/completions")) url += "/chat/completions";

        StringBuilder u = new StringBuilder();
        u.append("GOAL: ").append(goal).append("\n\nRECENT ACTIONS (oldest first):\n");
        if (recent.isEmpty()) u.append("(none yet)\n");
        for (String r : recent) u.append("- ").append(r).append('\n');
        if (!lastData.isEmpty()) u.append("\nLAST SCAN/INVENTORY DATA (about " + lastDataAge + " steps old, blocks may have changed):\n").append(lastData).append('\n');
        u.append("\nCURRENT OBSERVATION:\n").append(obs.toString());

        String system = "You are the brain of a Minecraft Bedrock player named AIBot. You act ONLY by calling tools.\n"
                + "SEE: scan / find list nearby blocks with positions; the observation gives pos, eye, yaw_pitch, 'look' (the block your crosshair is on, with its position), held buttons, nearby entities.\n"
                + "ACT: you press buttons like a real player. hold(button, seconds) keeps a button down and releases it by itself. "
                + "Buttons: forward, back, left, right, jump, sneak, sprint, mine (keep breaking the block your crosshair is on), attack (keep hitting the mob you look at). "
                + "tap(button) for jump/use/attack once. turn(yaw,pitch) rotates by degrees. look(x,y,z) turns to face a block. release stops buttons.\n"
                + "SHORTCUTS (they press the buttons for you): walk_to(x,y,z) and mine_block(x,y,z). Prefer them for 'go there' and 'break that block'; use raw buttons for fine control.\n"
                + "Rules:\n"
                + "1) Call 1 to 3 tools per turn; you see the results next turn. Buttons held in the same turn run at the same time.\n"
                + "2) Walking goes where you face (yaw only). To go to a block: look at it, hold forward (about 4 blocks per second), jump if something blocks you.\n"
                + "3) To mine by hand: find the block, walk until it is within 4 blocks, look at it, hold mine for 3-5 seconds, then check that obs 'look' changed or the block is gone. Mine the LOWEST block of a tree first.\n"
                + "4) Coordinates are integers (x east, y up, z south).\n"
                + "5) Never attack players and never destroy builds you did not make.\n"
                + "6) The bot is in survival: watch hp and hostile mobs. If stuck or idle, call wait.\n"
                + "7) Use say rarely, short, in " + (I18n.th ? "Thai" : "English") + ".";

        JSONArray messages = new JSONArray();
        messages.put(new JSONObject().put("role", "system").put("content", system));
        messages.put(new JSONObject().put("role", "user").put("content", u.toString()));
        JSONObject body = new JSONObject();
        body.put("model", model);
        body.put("temperature", 0.3);
        body.put("messages", messages);
        body.put("tools", TOOLS);
        body.put("tool_choice", "auto");

        Request req = new Request.Builder()
                .url(url)
                .header("Authorization", "Bearer " + key)
                .post(RequestBody.create(body.toString(), JSON_TYPE))
                .build();
        try (Response r = http.newCall(req).execute()) {
            String s = r.body() != null ? r.body().string() : "";
            if (!r.isSuccessful()) throw new Exception("HTTP " + r.code() + " " + trunc(s, 300));
            JSONObject j = new JSONObject(s);
            JSONArray ch = j.optJSONArray("choices");
            if (ch == null || ch.length() == 0) throw new Exception("no choices: " + trunc(s, 200));
            return ch.getJSONObject(0).getJSONObject("message");
        }
    }

    // ---------------------------------------------------------------- tool schemas
    private static JSONObject tool(String name, String desc, String... params) {
        try {
            JSONObject props = new JSONObject();
            JSONArray req = new JSONArray();
            for (String p : params) {
                boolean required = p.startsWith("*");
                if (required) p = p.substring(1);
                String[] kv = p.split(":");
                props.put(kv[0], new JSONObject().put("type", kv[1]));
                if (required) req.put(kv[0]);
            }
            JSONObject parameters = new JSONObject().put("type", "object").put("properties", props).put("required", req);
            JSONObject fn = new JSONObject().put("name", name).put("description", desc).put("parameters", parameters);
            return new JSONObject().put("type", "function").put("function", fn);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static JSONArray buildTools() {
        JSONArray t = new JSONArray();
        t.put(tool("scan", "Summarise the blocks around the bot (type, count, nearest position). Optional filter = part of a block name.", "radius:integer", "filter:string"));
        t.put(tool("find", "List the nearest positions of a block type, e.g. block='log' or 'iron_ore'.", "*block:string", "radius:integer"));
        t.put(tool("inventory", "List the bot's inventory slots."));
        t.put(tool("walk_to", "Walk to x,z by pressing forward and jump for you (no pathfinding; goes straight, jumps when stuck). Waits until arrived or failed.", "*x:integer", "*y:integer", "*z:integer"));
        t.put(tool("mine_block", "Walk next to the block at x,y,z, look at it and hold mine until it breaks. Waits until broken or failed. Use find first to get a real position.", "*x:integer", "*y:integer", "*z:integer"));
        t.put(tool("look", "Turn to face the centre of the block at x,y,z.", "*x:integer", "*y:integer", "*z:integer"));
        t.put(tool("turn", "Rotate the view by degrees: yaw + turns right (clockwise), yaw - turns left, pitch + looks down.", "yaw:integer", "pitch:integer"));
        t.put(tool("hold", "Hold a button down for some seconds (0.2-8), it releases by itself. Buttons: forward, back, left, right, jump, sneak, sprint, mine, attack.", "*button:string", "seconds:number"));
        t.put(tool("tap", "Press a button once: jump, use or attack.", "*button:string"));
        t.put(tool("release", "Release one button, or all buttons when button is empty.", "button:string"));
        t.put(tool("select_slot", "Select hotbar slot 0-8.", "*slot:integer"));
        t.put(tool("say", "Say something in the game chat.", "*text:string"));
        t.put(tool("wait", "Do nothing for a few seconds.", "seconds:integer"));
        return t;
    }
}
