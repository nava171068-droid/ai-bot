package com.example.aibridge;

import android.os.Handler;
import android.os.Looper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Tiny shared state + log, so the service can talk to the screen. */
final class Bus {
    interface Listener { void changed(); }

    private static final List<String> lines = new ArrayList<>();
    private static final Handler H = new Handler(Looper.getMainLooper());
    private static final SimpleDateFormat TF = new SimpleDateFormat("HH:mm:ss", Locale.US);
    static volatile boolean running = false;
    static volatile boolean mc = false;
    static volatile Listener listener;

    static synchronized void log(String s) {
        lines.add(TF.format(new Date()) + "  " + s);
        while (lines.size() > 200) lines.remove(0);
        fire();
    }

    static synchronized String text() {
        StringBuilder sb = new StringBuilder();
        for (int i = Math.max(0, lines.size() - 80); i < lines.size(); i++) sb.append(lines.get(i)).append('\n');
        return sb.toString();
    }

    static void fire() {
        final Listener l = listener;
        if (l != null) H.post(new Runnable() { public void run() { l.changed(); } });
    }
}
