# AI Minecraft Bot (Bedrock)

An AI plays Minecraft Bedrock through a GameTest **Simulated Player**.

- `addon/AI_BP` - Bedrock behavior pack. Spawns the bot and exposes `/scriptevent ai:cmd <command>` (walk, mine, place, attack, scan blocks ...). Replies are JSON lines starting with `[ai] `.
- `app` - Android app ("AI Bridge", English / Thai). Runs a WebSocket server on `127.0.0.1:3000` and the AI loop (any OpenAI-compatible API).

## Build (GitHub Actions)
Push this repo to GitHub. The **Build APK** workflow produces two artifacts: `AIBridge-debug-apk` (the app) and `AI_Player_Bot-mcaddon` (the add-on). Download them from the Actions run page.

## Use
1. Install the `.mcaddon`, create a world with **Beta APIs** and **cheats** on, enable the pack.
2. Install the APK, open it, fill in the AI link (e.g. `https://api.openai.com/v1`), key and model name, press **Start**.
3. In Minecraft: `/connect 127.0.0.1:3000`. The bot spawns and the AI starts playing.

Manual control without the app: `/scriptevent ai:cmd help`.
