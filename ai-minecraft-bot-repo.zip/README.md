# AI Minecraft Bot (Bedrock)

An AI plays Minecraft Bedrock through a GameTest **Simulated Player**.

- `addon/AI_BP` - Bedrock behavior pack. Spawns the bot and exposes `/scriptevent ai:cmd <command>` (safe on|off|drop n = lava/cliff guard; hold/tap/release buttons: forward, back, left, right, jump, sneak, sprint, mine, attack; turn, look, scan, find ...). Replies are JSON lines starting with `[ai] `.
- `app` - Android app ("AI Bridge", English / Thai). Runs a WebSocket server on `127.0.0.1:3000` and the AI loop (any OpenAI-compatible API).

## Build (GitHub Actions)
Push this repo to GitHub. The **Build APK** workflow produces two artifacts: `AIBridge-debug-apk` (the app) and `AI_Player_Bot-mcaddon` (the add-on). Download them from the Actions run page.

## Use
1. Install the `.mcaddon`, create a world with **Beta APIs** and **cheats** on, enable the pack.
2. Install the APK, open it, fill in the AI link (e.g. `https://api.openai.com/v1`), key and model name, press **Start**.
3. In Minecraft: `/connect 127.0.0.1:3000`. The bot spawns and the AI starts playing.

Manual control without the app: `/scriptevent ai:cmd help`.

## v0.10 - faster, AI still in charge
- **Reflexes (in the add-on, no LLM):** fights monsters that come within 8 blocks, eats when hp <= 14. `reflex on|off|hp N`. The AI gets a `REFLEX` notice and keeps planning.
- **`collect <block> [n]`:** find + walk + mine + pick up, repeated, in one call (tool `collect` in the app).
- **`fight [mob]` tool:** the AI can hunt on purpose (animals for food, etc.).
- App: shorter waits, logs `LLM <n> ms` per decision so you can see how slow the model is.

## v0.10.1 - rate limits
- 429 (tokens per minute) is now handled: the app waits exactly the time the server says and then paces itself under the limit.
- Shorter system prompt and tool descriptions (fewer tokens per request); the AI explores when no trees are near.
