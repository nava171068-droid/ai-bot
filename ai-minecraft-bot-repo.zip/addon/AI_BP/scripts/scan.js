// AI Player Bot - scan.js : turns the world around the bot into short, LLM-friendly data.
const SKIP = new Set(["air", "cave_air", "void_air"]);
const short = (id) => id.replace("minecraft:", "");
const r1 = (n) => Math.round(n * 10) / 10;

// Blocks in a box around `c` (horizontal radius r, vertical radius vr). Without `filter`: one entry per block type (count + nearest).
// With `filter` (substring of the block id): the nearest hits with their positions.
export function scanBlocks(dim, c, r = 6, filter = "", vr = null, maxHits = 10) {
  r = Math.max(1, Math.min(12, r | 0));
  vr = Math.max(1, Math.min(8, vr ?? Math.min(r, 6)));
  const cx = Math.floor(c.x), cy = Math.floor(c.y), cz = Math.floor(c.z);
  const q = (filter ?? "").toLowerCase();
  const types = {}, hits = [];
  let unloaded = 0;
  let lo = -1e9, hi = 1e9; try { const hr = dim.heightRange; lo = hr.min; hi = hr.max - 1; } catch (_) {}
  for (let dx = -r; dx <= r; dx++) for (let dz = -r; dz <= r; dz++) for (let dy = -vr; dy <= vr; dy++) {
    const x = cx + dx, y = cy + dy, z = cz + dz;
    if (y < lo || y > hi) continue;   // below bedrock / above the sky: not a real block
    let b; try { b = dim.getBlock({ x, y, z }); } catch (_) { b = undefined; }
    if (!b) { unloaded++; continue; }
    const id = short(b.typeId);
    if (SKIP.has(id)) continue;
    const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
    if (q) { if (id.includes(q)) hits.push([x, y, z, id, r1(d)]); continue; }
    const t = types[id] ?? (types[id] = { n: 0, near: null, d: 1e9 });
    t.n++;
    if (d < t.d) { t.d = d; t.near = [x, y, z]; }
  }
  if (q) { hits.sort((a, b) => a[4] - b[4]); return { event: "find", q, r, at: [cx, cy, cz], hits: hits.slice(0, maxHits), total: hits.length, unloaded }; }
  const list = Object.entries(types).sort((a, b) => a[1].d - b[1].d).slice(0, 24);
  const blocks = {};
  for (const [id, t] of list) blocks[id] = { n: t.n, near: t.near, d: r1(t.d) };
  return { event: "scan", r, vr, at: [cx, cy, cz], blocks, unloaded };
}

export function nearbyEntities(dim, bot, range = 16, max = 15) {
  const out = [];
  let es = []; try { es = dim.getEntities({ location: bot.location, maxDistance: range }); } catch (_) {}
  const b = bot.location;
  for (const e of es) {
    if (e.id === bot.id) continue;
    let l; try { l = e.location; } catch (_) { continue; }
    const d = Math.hypot(l.x - b.x, l.y - b.y, l.z - b.z);
    const o = { t: short(e.typeId), d: r1(d), p: [Math.floor(l.x), Math.floor(l.y), Math.floor(l.z)] };
    if (e.typeId === "minecraft:player") o.name = e.name;
    else if (e.nameTag) o.name = e.nameTag;
    out.push(o);
  }
  out.sort((a, b2) => a.d - b2.d);
  return out.slice(0, max);
}

export function inventory(bot) {
  const inv = {}, slots = [];
  try {
    const c = bot.getComponent("minecraft:inventory").container;
    for (let i = 0; i < c.size; i++) {
      const it = c.getItem(i);
      if (!it) continue;
      const id = short(it.typeId);
      inv[id] = (inv[id] ?? 0) + it.amount;
      slots.push([i, id, it.amount]);
    }
  } catch (_) {}
  return { inv, slots };
}

export function observe(bot, task) {
  const l = bot.location, dim = bot.dimension;
  let hp = null; try { const h = bot.getComponent("minecraft:health"); hp = r1(h.currentValue); } catch (_) {}
  let below = null; try { below = short(dim.getBlock({ x: Math.floor(l.x), y: Math.floor(l.y) - 1, z: Math.floor(l.z) }).typeId); } catch (_) {}
  const { inv } = inventory(bot);
  let slot = null; try { slot = bot.selectedSlotIndex; } catch (_) {}
  let rot = null; try { const r = bot.getRotation(); rot = [Math.round(r.y), Math.round(r.x)]; } catch (_) {}
  let eye = null; try { const e = bot.getHeadLocation(); eye = [r1(e.x), r1(e.y), r1(e.z)]; } catch (_) {}
  let look = null;
  try { const h = bot.getBlockFromViewDirection({ maxDistance: 6 }); if (h && h.block) { const q = h.block.location; look = { b: short(h.block.typeId), p: [q.x, q.y, q.z] }; } } catch (_) {}
  return {
    event: "obs", yaw_pitch: rot, eye, look, pos: [r1(l.x), r1(l.y), r1(l.z)], dim: dim.id.replace("minecraft:", ""), hp, below, slot, inv,
    near: nearbyEntities(dim, bot), task: task ? task.type : null,
  };
}
