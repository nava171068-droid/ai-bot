// AI Player Bot - launcher.js
// Creates ONE GameTest SimulatedPlayer and keeps it alive. Pattern taken from the ITS add-on (cp_listplayer.js):
//   * registerAsync("ai","bot") owns the simulated player and loops `await test.idle(1)` while it should live
//   * the test can only be started with `/gametest run ai:bot`, which places marker blocks where it runs, so it is run from high in the sky
//     (ticking area) and the markers are cleared afterwards. Three ways are tried: "dimension", "anchor" (armor stand), "player" (needs OP).
import { world, system, GameMode, BlockVolume } from "@minecraft/server";

const TEST = "ai:bot";
export const S = {
  sim: null,          // the SimulatedPlayer while it exists
  name: "AIBot",
  want: false,        // someone asked for the bot
  stop: false,        // asks the running test to finish
  onTick: null,       // main.js: (bot) => void, called every tick inside the test loop
  spawnAt: null,      // { x, y, z } and dimension where the bot appears
  spawnDim: "overworld",
  gt: null, gtErr: "", lastErr: "", via: "-", launching: 0,
};
export const alive = () => { try { return !!S.sim && S.sim.isValid; } catch (_) { return false; } };

const SKY = { x: 2000064, y: 300, z: 2000064 };
let areaAdded = false;
function clearSky(dim) {
  try { dim.fillBlocks(new BlockVolume({ x: SKY.x - 4, y: SKY.y - 3, z: SKY.z - 4 }, { x: SKY.x + 5, y: SKY.y + 4, z: SKY.z + 5 }), "minecraft:air"); } catch (_) {}
}

async function registerTest() {
  try { S.gt = await import("@minecraft/server-gametest"); } catch (e) { S.gtErr = String(e); console.warn("[ai] server-gametest not available: " + S.gtErr); return; }
  try {
    S.gt.registerAsync("ai", "bot", async (test) => {
      const sky = world.getDimension("overworld");
      let p;
      try { p = test.spawnSimulatedPlayer({ x: 0, y: 0, z: 0 }, S.name, GameMode.Survival); }
      catch (e) { S.lastErr = "spawn: " + e; test.fail("spawn failed"); return; }
      S.sim = p;
      try { if (S.spawnAt) p.teleport(S.spawnAt, { dimension: world.getDimension(S.spawnDim), keepVelocity: false }); } catch (e) { S.lastErr = "tp: " + e; }
      let away = 0;
      while (!S.stop) {
        let anyone = false;
        try { anyone = world.getAllPlayers().some((x) => x.id !== p.id); } catch (_) {}
        if (!anyone) { if (++away > 200) break; } else away = 0;   // leaves when no real player is online
        try { if (S.onTick) S.onTick(p); } catch (e) { S.lastErr = "tick: " + e; }
        await test.idle(1);
      }
      S.sim = null;
      clearSky(sky);
      test.succeed();
    }).structureName("ai:sim_empty").maxTicks(1728000).padding(0);
  } catch (e) { S.gtErr = String(e); console.warn("[ai] register failed: " + S.gtErr); }
}
registerTest();

const METHODS = ["dimension", "anchor", "player"];
let mIdx = 0, mTries = 0, locked = null;
function realPlayers() { try { return world.getAllPlayers().filter((p) => !(S.sim && p.id === S.sim.id) && p.name !== S.name); } catch (_) { return []; } }

function launch() {
  const host = realPlayers()[0];
  if (!host) return;
  if (!S.spawnAt) { S.spawnAt = { x: host.location.x + 1.5, y: host.location.y, z: host.location.z + 1.5 }; S.spawnDim = host.dimension.id.replace("minecraft:", ""); }
  S.launching = system.currentTick + 200;
  const ov = world.getDimension("overworld");
  try {
    if (!areaAdded) {
      const area = `tickingarea add circle ${SKY.x} ${SKY.y} ${SKY.z} 1 ai_sim true`;
      try { ov.runCommand(area); } catch (_) { host.runCommand(`execute in overworld run ${area}`); }
      areaAdded = true; S.launching = system.currentTick + 60;
      return;
    }
    if (!locked) { if (++mTries > 2) { mIdx = Math.min(mIdx + 1, METHODS.length - 1); mTries = 1; } }
    S.via = locked ?? METHODS[mIdx];
    const sky = { x: SKY.x + 0.5, y: SKY.y, z: SKY.z + 0.5 };
    if (S.via === "dimension") {
      const r = ov.runCommand(`execute in overworld positioned ${SKY.x} ${SKY.y} ${SKY.z} run gametest run ${TEST}`);
      if (r && r.successCount === 0) S.lastErr = "dimension: gametest run returned 0";
    } else if (S.via === "anchor") {
      let anc = ov.getEntities({ tags: ["ai_sim_anchor"] })[0];
      if (!anc) { anc = ov.spawnEntity("minecraft:armor_stand", sky); anc.addTag("ai_sim_anchor"); }
      anc.teleport(sky);
      const r = ov.runCommand(`execute as @e[tag=ai_sim_anchor] at @s run gametest run ${TEST}`);
      if (r && r.successCount === 0) S.lastErr = "anchor: gametest run returned 0";
      let n = 0;
      const hold = system.runInterval(() => { try { anc.teleport(sky); } catch (_) {} if (++n > 100) system.clearRun(hold); }, 1);
    } else {
      const hd = host.dimension, hp = host.location, hr = host.getRotation();
      try { host.teleport(sky, { dimension: ov, keepVelocity: false }); } catch (e) { S.lastErr = "teleport up: " + e; return; }
      const res = host.runCommand(`gametest run ${TEST}`);
      if (res && res.successCount === 0) S.lastErr = "player: gametest run did not start (operator / cheats needed)";
      let n = 0;
      const back = system.runInterval(() => {
        if (alive() || ++n > 60) {
          system.clearRun(back);
          try { if (host.isValid) host.teleport(hp, { dimension: hd, rotation: hr, keepVelocity: false }); } catch (e) { S.lastErr = "teleport back: " + e; }
        }
      }, 1);
    }
  } catch (e) { S.lastErr = (S.via || "launch") + ": " + e; console.warn("[ai] " + S.lastErr); mTries = 2; }
}

system.runInterval(() => {
  try {
    if (!S.gt) return;
    const a = alive();
    if (a && !locked && S.via !== "-") locked = S.via;
    if (!a && S.sim) S.sim = null;
    if (!S.want) { if (a) S.stop = true; return; }
    S.stop = false;
    if (!a && realPlayers().length > 0 && system.currentTick >= S.launching) launch();
  } catch (_) {}
}, 10);

export function requestSpawn(name, at, dim) {
  if (name) S.name = name;
  if (at) { S.spawnAt = at; S.spawnDim = dim ?? "overworld"; }
  S.want = true; S.stop = false; S.launching = 0;
}
export function requestDespawn() { S.want = false; S.stop = true; }
