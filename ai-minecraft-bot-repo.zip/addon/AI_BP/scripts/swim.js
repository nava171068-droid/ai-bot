// AI Player Bot - swim.js : water awareness. Tells the AI when the bot is in water and where the nearest shore is.
import { LAVA, HURT, isSolid } from "./safety.js";

export const SWIM = { auto: true };   // auto: swim ashore by itself when the head is under water / the bot floats and nobody gave an order
const r1 = (n) => Math.round(n * 10) / 10;
const WATER = new Set(["minecraft:water", "minecraft:flowing_water"]);

export function inWater(bot) {
  try { if (bot.isInWater !== undefined) return !!bot.isInWater; } catch (_) {}
  try { const l = bot.location, b = bot.dimension.getBlock({ x: Math.floor(l.x), y: Math.floor(l.y), z: Math.floor(l.z) }); return !!b && WATER.has(b.typeId); } catch (_) { return false; }
}
export function headUnder(bot) {
  try { const e = bot.getHeadLocation(), b = bot.dimension.getBlock({ x: Math.floor(e.x), y: Math.floor(e.y), z: Math.floor(e.z) }); return !!b && WATER.has(b.typeId); } catch (_) { return false; }
}

const get = (dim, x, y, z) => { try { return dim.getBlock({ x, y, z }); } catch (_) { return undefined; } };
const liquid = (b) => { try { return !!b.isLiquid; } catch (_) { return false; } };

// a place the bot can stand: feet + head free (not water), solid safe floor, no lava beside the feet
function standOk(dim, x, y, z) {
  const f = get(dim, x, y, z), h = get(dim, x, y + 1, z), g = get(dim, x, y - 1, z);
  if (!f || !h || !g) return false;
  if (liquid(f) || liquid(h) || isSolid(f) || isSolid(h)) return false;
  if (HURT.has(f.typeId) || HURT.has(h.typeId)) return false;
  if (liquid(g) || !isSolid(g) || LAVA.has(g.typeId) || HURT.has(g.typeId)) return false;
  for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const n = get(dim, x + dx, y, z + dz); if (n && LAVA.has(n.typeId)) return false; }
  return true;
}

// nearest dry standing spot around `loc` (searches in rings up to R blocks). returns { x, y, z, d } or null
export function findShore(dim, loc, R = 16) {
  const cx = Math.floor(loc.x), cz = Math.floor(loc.z), fy = Math.floor(loc.y);
  let best = null, ringFound = -1;
  for (let r = 1; r <= R; r++) {
    if (ringFound >= 0 && r > ringFound + 1) break;   // one more ring after the first hit: a straight line can beat a corner
    for (let dx = -r; dx <= r; dx++) for (let dz = -r; dz <= r; dz++) {
      if (Math.max(Math.abs(dx), Math.abs(dz)) !== r) continue;
      for (let y = fy + 2; y >= fy - 2; y--) {
        if (!standOk(dim, cx + dx, y, cz + dz)) continue;
        const d = Math.hypot(cx + dx + 0.5 - loc.x, cz + dz + 0.5 - loc.z) + Math.abs(y - fy) * 0.5;
        if (!best || d < best.d) best = { x: cx + dx, y, z: cz + dz, d };
        if (ringFound < 0) ringFound = r;
        break;
      }
    }
  }
  return best;
}

// goes into every observation; undefined when the bot is not in water
export function waterInfo(bot) {
  if (!inWater(bot)) return undefined;
  const o = { in: true, head_under: headUnder(bot) };
  try { const a = bot.getComponent("minecraft:breathable"); if (a && a.airSupply !== undefined) o.air = a.airSupply; } catch (_) {}
  const s = findShore(bot.dimension, bot.location, 16);
  o.shore = s ? { at: [s.x, s.y, s.z], d: r1(s.d) } : null;
  o.hint = s ? "call swim_to_shore" : "no shore within 16 blocks";
  return o;
}
