// AI Player Bot - safety.js : looks at the ground ahead so the bot does not walk into lava or off a cliff.
// probe()  = check the blocks in front of the bot in one direction.
// around() = the same check in 4 directions (front / back / left / right), short enough to put in every observation.

export const SAFE = { on: true, maxDrop: 3 };   // maxDrop = how many blocks the bot may fall down (3 = no fall damage)

export const LAVA = new Set(["minecraft:lava", "minecraft:flowing_lava"]);
// not lava, but hurts when walked onto
export const HURT = new Set(["minecraft:magma", "minecraft:fire", "minecraft:soul_fire", "minecraft:cactus", "minecraft:campfire", "minecraft:soul_campfire", "minecraft:sweet_berry_bush", "minecraft:wither_rose"]);
const r1 = (n) => Math.round(n * 10) / 10;

export function isSolid(b) {
  let s; try { s = b.isSolid; } catch (_) {}
  if (s !== undefined) return !!s;
  try { return !b.isAir && !b.isLiquid; } catch (_) { return false; }
}

// One column (x,z) in front of the bot. fy = the block row of the bot's feet.
// returns null when it is fine to step there, otherwise { hz, y }:  "lava" | "hurt:<block>" | "drop"
function column(dim, x, z, fy) {
  const lo = fy - 1 - SAFE.maxDrop;
  for (let y = fy + 1; y >= lo; y--) {
    let b; try { b = dim.getBlock({ x, y, z }); } catch (_) { return null; }
    if (!b) return null;                       // chunk not loaded: do not freeze the bot
    const id = b.typeId;
    if (LAVA.has(id)) return { hz: "lava", y };
    if (HURT.has(id)) return { hz: "hurt:" + id.replace("minecraft:", ""), y };
    let liq = false; try { liq = b.isLiquid; } catch (_) {}
    if (liq) return null;                      // water: soft landing
    if (isSolid(b)) return null;               // a wall (step up / blocked) or safe ground
  }
  return { hz: "drop", y: lo };                // nothing to stand on within maxDrop blocks
}

// look `reach` blocks ahead along (dx,dz). returns null (safe) or { hz, d, at:[x,y,z] }
export function probe(dim, loc, dx, dz, reach = 2.5) {
  const n = Math.hypot(dx, dz);
  if (n < 1e-6) return null;
  dx /= n; dz /= n;
  const fy = Math.floor(loc.y + 0.05);
  const seen = new Set([Math.floor(loc.x) + "," + Math.floor(loc.z)]);
  for (let d = 0.6; d <= reach + 1e-6; d += 0.4) {
    const x = Math.floor(loc.x + dx * d), z = Math.floor(loc.z + dz * d), key = x + "," + z;
    if (seen.has(key)) continue;
    seen.add(key);
    const h = column(dim, x, z, fy);
    if (h) return { hz: h.hz, d: r1(d), at: [x, h.y, z] };
  }
  return null;
}

// yaw (degrees) + forward/left amounts -> world direction. forward = (-sin, cos), left = (cos, sin)
export function dirFrom(yaw, fwd, left) {
  const k = Math.PI / 180, s = Math.sin(yaw * k), c = Math.cos(yaw * k);
  return [-s * fwd + c * left, c * fwd + s * left];
}

// { f: "ok" | "lava@2", b: ..., l: ..., r: ... }   (relative to where the bot is facing)
export function around(bot, reach = 3) {
  let yaw = 0; try { yaw = bot.getRotation().y; } catch (_) {}
  const out = {};
  for (const [k, f, l] of [["f", 1, 0], ["b", -1, 0], ["l", 0, 1], ["r", 0, -1]]) {
    const [dx, dz] = dirFrom(yaw, f, l);
    const h = probe(bot.dimension, bot.location, dx, dz, reach);
    out[k] = h ? h.hz + "@" + Math.ceil(h.d) : "ok";
  }
  return out;
}
