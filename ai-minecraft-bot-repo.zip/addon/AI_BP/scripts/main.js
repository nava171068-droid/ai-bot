// AI Player Bot - main.js : commands for the simulated player.   /scriptevent ai:cmd <command> [args]
// Every result is one JSON line  {"event":...}  written to the content log and (echo on) to chat as "[ai] {...}".
// A later bridge (e.g. the /connect 127.0.0.1:3000 app) only has to read those lines and send /scriptevent ai:cmd ... back.
import { world, system, Direction, ItemStack } from "@minecraft/server";
import { S, alive, requestSpawn, requestDespawn } from "./launcher.js";
import { scanBlocks, observe, inventory } from "./scan.js";

// transport = how result lines reach a /connect WebSocket client:  chat (world.sendMessage) | say (/say) | tellraw (/tellraw)
const cfg = { echo: true, transport: "chat" };
let chunkId = 0;
function emit(o) {
  let s; try { s = JSON.stringify(o); } catch (_) { s = String(o); }
  console.warn("[ai] " + s);
  if (!cfg.echo && cfg.transport !== "bot") return;
  try {
    if (cfg.transport === "bot") {
      // the simulated player says it in chat: a real chat line, so the /connect client gets it as PlayerMessage.
      // chat lines are short, so long JSON is cut into  [ai#id.i/n] pieces that the app glues together.
      if (!alive()) return;
      const CH = 170;
      if (s.length <= CH) { S.sim.chat("[ai] " + s); return; }
      const id = ++chunkId, n = Math.ceil(s.length / CH);
      for (let i = 0; i < n; i++) S.sim.chat("[ai#" + id + "." + i + "/" + n + "] " + s.slice(i * CH, (i + 1) * CH));
    } else if (cfg.transport === "say") world.getDimension("overworld").runCommand("say [ai] " + s);
    else if (cfg.transport === "tellraw") world.getDimension("overworld").runCommand("tellraw @a " + JSON.stringify({ rawtext: [{ text: "[ai] " + s }] }));
    else world.sendMessage("\u00a78[ai] " + s);
  } catch (_) {}
}

const inbox = [];         // commands waiting to run inside the test loop (SimulatedPlayer calls are made from there)
let task = null;          // the one long-running job (goto / follow / break / place / attack)
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z);
const num = (s) => { const n = Number(s); return Number.isFinite(n) ? n : null; };
const flr = (p) => ({ x: Math.floor(p.x), y: Math.floor(p.y), z: Math.floor(p.z) });
const realPlayers = () => world.getAllPlayers().filter((p) => !(S.sim && p.id === S.sim.id));
const findPlayer = (name) => realPlayers().find((p) => p.name.toLowerCase() === String(name).toLowerCase());

function finish(ok, msg) { if (!task) return; emit({ event: "done", task: task.type, ok, msg }); task = null; }
function setTask(t, ticks) { if (task) emit({ event: "cancel", task: task.type }); task = { ...t, nextNav: 0, deadline: ticks ? system.currentTick + ticks : Infinity }; }

// "x y z" or "me" (the player who sent the command) -> position
function readPos(a, i, ctx) {
  if (a[i] === "me") { const p = ctx.src ?? realPlayers()[0]; return p ? { pos: { ...p.location }, used: 1 } : null; }
  const x = num(a[i]), y = num(a[i + 1]), z = num(a[i + 2]);
  return x === null || y === null || z === null ? null : { pos: { x, y, z }, used: 3 };
}

function nav(bot, pos, speed) {
  const r = bot.navigateToLocation(pos, speed);
  if (r && r.isFullPath === false && task && !task.warned) { task.warned = true; emit({ event: "warn", msg: "no full path, going as far as possible" }); }
}

// a free spot next to the block (feet + head room, solid floor) - never path INTO the solid block itself
function standSpot(dim, bot, pos) {
  let best = null, bd = 1e9;
  for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
    const x = pos.x + dx, z = pos.z + dz;
    for (const dy of [0, -1, 1]) {
      const y = pos.y + dy;
      let f, h, g;
      try { f = dim.getBlock({ x, y, z }); h = dim.getBlock({ x, y: y + 1, z }); g = dim.getBlock({ x, y: y - 1, z }); } catch (_) { continue; }
      if (!f || !h || !g || !isAir(f) || !isAir(h) || isAir(g) || g.isLiquid) continue;
      const d = dist(bot.location, { x: x + 0.5, y, z: z + 0.5 });
      if (d < bd) { bd = d; best = { x: x + 0.5, y, z: z + 0.5 }; }
    }
  }
  return best;
}

// walk until the target block is within reach; true when it is
function inReach(bot, pos, t, now) {
  const c = { x: pos.x + 0.5, y: pos.y + 0.5, z: pos.z + 0.5 };
  const e = bot.getHeadLocation ? bot.getHeadLocation() : bot.location;
  if (dist(e, c) <= 4.5) return true;
  if (now >= t.nextNav) { nav(bot, standSpot(bot.dimension, bot, pos) ?? c, 1); t.nextNav = now + 20; }
  return false;
}

const FACES = [[0, -1, 0, Direction.Up], [0, 1, 0, Direction.Down], [0, 0, 1, Direction.North], [0, 0, -1, Direction.South], [1, 0, 0, Direction.West], [-1, 0, 0, Direction.East]];
const isAir = (b) => !b || b.typeId === "minecraft:air" || b.typeId === "minecraft:cave_air";

function findTarget(bot, t) {
  let es = []; try { es = bot.dimension.getEntities({ location: bot.location, maxDistance: 16 }); } catch (_) {}
  let best = null, bd = 1e9;
  for (const e of es) {
    if (e.id === bot.id || e.typeId === "minecraft:item" || e.typeId === "minecraft:xp_orb") continue;
    if (e.typeId === "minecraft:player" && t.filter !== "player") continue;   // never attacks players unless asked by name of the type
    if (t.filter && !e.typeId.includes(t.filter)) continue;
    const d = dist(bot.location, e.location);
    if (d < bd) { bd = d; best = e; }
  }
  return best;
}

function runTask(bot) {
  const t = task, now = system.currentTick, loc = bot.location, dim = bot.dimension;
  if (now > t.deadline) { try { bot.stopMoving(); } catch (_) {} return finish(false, "timeout"); }
  switch (t.type) {
    case "goto": {
      if (dist(loc, t.pos) < 1.8) { bot.stopMoving(); return finish(true, "arrived"); }
      if (now >= t.nextNav) { nav(bot, t.pos, t.speed); t.nextNav = now + 20; }
      break;
    }
    case "follow": {
      const p = findPlayer(t.name);
      if (!p) return finish(false, "player not found");
      if (p.dimension.id !== dim.id) { bot.teleport(p.location, { dimension: p.dimension }); break; }
      const d = dist(loc, p.location);
      if (d > t.dist) { if (now >= t.nextNav) { bot.navigateToEntity(p, 1); t.nextNav = now + 10; t.moving = true; } }
      else if (t.moving) { bot.stopMoving(); t.moving = false; }
      break;
    }
    case "break": {
      const b = dim.getBlock(t.pos);
      if (isAir(b)) return finish(true, "broken");
      if (!inReach(bot, t.pos, t, now)) break;
      if (t.walking) { bot.stopMoving(); t.walking = false; }
      bot.lookAtBlock(t.pos);
      const hit = bot.breakBlock(t.pos);
      if (t.t0 === undefined) t.t0 = now;
      // survival mining by hand can stall (no progress even while looking at the block): after 5 s finish it with "destroy"
      if (now - t.t0 > 100 && !t.forced) {
        t.forced = true;
        try { dim.runCommand(`setblock ${t.pos.x} ${t.pos.y} ${t.pos.z} air destroy`); } catch (_) {}
        emit({ event: "warn", msg: "breakBlock made no progress (last=" + hit + "), used destroy fallback" });
      }
      break;
    }
    case "place": {
      const b = dim.getBlock(t.pos);
      if (b && b.typeId === t.block) return finish(true, "placed");
      if (!t.tried) {
        if (!isAir(b) && !(b && b.isLiquid)) return finish(false, "target not empty: " + b.typeId);
        if (!inReach(bot, t.pos, t, now)) break;
        const { slots } = inventory(bot);
        const it = slots.find((s) => "minecraft:" + s[1] === t.block || s[1] === t.block.replace("minecraft:", ""));
        if (!it) return finish(false, "item not in inventory: " + t.block);
        if (it[0] > 8) return finish(false, "item is in slot " + it[0] + ", move it to the hotbar (0-8)");
        bot.selectSlot(it[0]);
        const f = FACES.find(([dx, dy, dz]) => { const n = dim.getBlock({ x: t.pos.x + dx, y: t.pos.y + dy, z: t.pos.z + dz }); return n && !isAir(n) && !n.isLiquid; });
        if (!f) return finish(false, "no solid block next to the target");
        const nb = { x: t.pos.x + f[0], y: t.pos.y + f[1], z: t.pos.z + f[2] };
        bot.stopMoving(); bot.lookAtBlock(nb);
        bot.interactWithBlock(nb, f[3]);
        t.tried = now; t.retry = (t.retry ?? 0) + 1;
      } else if (now - t.tried > 10) {
        if (t.retry >= 3) return finish(false, "place failed");
        t.tried = 0;
      }
      break;
    }
    case "attack": {
      if (!t.target || !t.target.isValid) {
        t.target = findTarget(bot, t);
        if (!t.target) return finish(t.hits > 0, t.hits > 0 ? "no target left" : "no target nearby");
      }
      const e = t.target, d = dist(loc, e.location);
      if (d > 2.8) { if (now >= t.nextNav) { bot.navigateToEntity(e, 1.2); t.nextNav = now + 10; } }
      else { bot.stopMoving(); bot.lookAtEntity(e); if (now >= (t.nextHit ?? 0)) { bot.attackEntity(e); t.nextHit = now + 12; t.hits = (t.hits ?? 0) + 1; } }
      break;
    }
  }
}

// ---------------------------------------------------------------- "buttons": what a player's fingers do
// A held button stays on until its timer ends (or release). Applied every tick inside the test loop.
const BTN = ["forward", "back", "left", "right", "jump", "sneak", "sprint", "mine", "attack"];
const held = {};                 // button -> tick when it lets go (Infinity = until release)
let moving = false, mining = false, nextHit = 0;
const heldList = () => BTN.filter((b) => held[b]);
const stopMine = (bot) => { if (mining) { try { bot.stopBreakingBlock(); } catch (_) {} mining = false; } };

function applyInputs(bot, now) {
  for (const k of BTN) if (held[k] && now > held[k]) delete held[k];
  const fb = (held.forward ? 1 : 0) - (held.back ? 1 : 0);
  const lr = (held.left ? 1 : 0) - (held.right ? 1 : 0);
  if (fb || lr) { bot.moveRelative(lr, fb, held.sprint ? 1.4 : 1); moving = true; }
  else if (moving) { bot.stopMoving(); moving = false; }
  try { bot.isSneaking = !!held.sneak; } catch (_) {}
  try { bot.isSprinting = !!held.sprint && fb > 0; } catch (_) {}
  if (held.jump) { let g = true; try { g = bot.isOnGround; } catch (_) {} if (g) bot.jump(); }
  if (held.mine) {
    let h = null; try { h = bot.getBlockFromViewDirection({ maxDistance: 5.5 }); } catch (_) {}
    if (h && h.block && !isAir(h.block)) { bot.breakBlock(h.block.location, h.face); mining = true; }
    else stopMine(bot);
  } else stopMine(bot);
  if (held.attack && now >= nextHit) { try { bot.attack(); } catch (_) {} nextHit = now + 12; }
}

// ---------------------------------------------------------------- commands
const HELP = "spawn [name] | despawn | status | obs | inv | scan [r] [filter] | find <block> [r] | goto x y z|me [speed] | follow <player|me> [dist] | stop | " +
  "hold <button> [sec] | release [button|all] | tap jump|use|attack | turn dyaw dpitch | look x y z|me | lookat <player> | jump | attack [type] | hit | break x y z | place x y z <block> | use | slot <0-8> | give <item> [n] | say <text> | tp x y z|me | echo on|off | transport bot|chat|say|tellraw | ping";

const C = {
  help: () => emit({ event: "help", cmds: HELP }),
  status: () => emit({ event: "status", v: "0.4", alive: alive(), want: S.want, name: S.name, via: S.via, gametest: !!S.gt, task: task?.type ?? null, err: S.gtErr || S.lastErr || null }),
  spawn: (a, ctx) => {
    const p = ctx.src ?? realPlayers()[0];
    const at = p ? { x: p.location.x + 1.5, y: p.location.y, z: p.location.z + 1.5 } : undefined;
    requestSpawn(a[0], at, p ? p.dimension.id.replace("minecraft:", "") : undefined);
    emit({ event: "spawning", name: S.name });
  },
  despawn: () => { task = null; requestDespawn(); emit({ event: "despawning" }); },
  ping: () => emit({ event: "pong", t: system.currentTick }),
  transport: (a) => { if (["chat", "say", "tellraw", "bot"].includes(a[0])) cfg.transport = a[0]; emit({ event: "transport", mode: cfg.transport }); },
  echo: (a) => { cfg.echo = a[0] !== "off"; emit({ event: "echo", on: cfg.echo }); },
};
const B = {   // need a living bot
  obs: (bot) => emit({ ...observe(bot, task), held: heldList() }),
  hold: (bot, a) => {      // hold <button> [seconds]   (no seconds = until release)
    const b = (a[0] ?? "").toLowerCase();
    if (!BTN.includes(b)) return emit({ event: "error", msg: "usage: hold <" + BTN.join("|") + "> [seconds]" });
    const sec = num(a[1]);
    if (task) { emit({ event: "cancel", task: task.type }); task = null; }
    held[b] = sec === null || sec <= 0 ? Infinity : system.currentTick + Math.round(Math.min(sec, 30) * 20);
    emit({ event: "ok", cmd: "hold", button: b, seconds: sec });
  },
  release: (bot, a) => {   // release [button|all]
    const b = (a[0] ?? "all").toLowerCase();
    if (b === "all") for (const k of BTN) delete held[k]; else delete held[b];
    emit({ event: "ok", cmd: "release", button: b });
  },
  tap: (bot, a) => {       // tap jump | use | attack
    const b = (a[0] ?? "").toLowerCase();
    if (b === "jump") bot.jump(); else if (b === "use") bot.interact(); else if (b === "attack") bot.attack();
    else return emit({ event: "error", msg: "usage: tap jump|use|attack" });
    emit({ event: "ok", cmd: "tap", button: b });
  },
  turn: (bot, a) => {      // turn <dyaw> <dpitch>   degrees, relative (yaw + = turn left, pitch + = look down)
    const dy = num(a[0]) ?? 0, dp = num(a[1]) ?? 0;
    const r = bot.getRotation(), yaw = r.y + dy, pitch = Math.max(-89, Math.min(89, r.x + dp));
    const k = Math.PI / 180, e = bot.getHeadLocation();
    bot.lookAtLocation({ x: e.x - Math.sin(yaw * k) * Math.cos(pitch * k) * 10, y: e.y - Math.sin(pitch * k) * 10, z: e.z + Math.cos(yaw * k) * Math.cos(pitch * k) * 10 });
    emit({ event: "ok", cmd: "turn" });
  },
  inv: (bot) => emit({ event: "inv", ...inventory(bot) }),
  scan: (bot, a) => {
    const r = a[0] !== undefined && num(a[0]) !== null ? num(a[0]) : 6;
    const filter = num(a[0]) !== null ? a[1] : a[0];
    emit(scanBlocks(bot.dimension, bot.location, r, filter ?? ""));
  },
  find: (bot, a) => emit(scanBlocks(bot.dimension, bot.location, num(a[1]) ?? 10, a[0] ?? "", null, 10)),
  goto: (bot, a, ctx) => {
    const r = readPos(a, 0, ctx); if (!r) return emit({ event: "error", msg: "usage: goto x y z | me [speed]" });
    setTask({ type: "goto", pos: r.pos, speed: num(a[r.used]) ?? 1 }, 20 * 60);
    emit({ event: "started", task: "goto", to: [r.pos.x, r.pos.y, r.pos.z] });
  },
  follow: (bot, a, ctx) => {
    const name = a[0] === "me" || !a[0] ? (ctx.src ?? realPlayers()[0])?.name : a[0];
    if (!name) return emit({ event: "error", msg: "usage: follow <player|me> [dist]" });
    setTask({ type: "follow", name, dist: num(a[1]) ?? 3 });
    emit({ event: "started", task: "follow", name });
  },
  stop: (bot) => { try { bot.stopMoving(); } catch (_) {} for (const k of BTN) delete held[k]; const t = task; task = null; emit({ event: "stopped", task: t?.type ?? null }); },
  look: (bot, a, ctx) => { const r = readPos(a, 0, ctx); if (!r) return emit({ event: "error", msg: "usage: look x y z | me" }); bot.lookAtLocation(r.pos); emit({ event: "ok", cmd: "look" }); },
  lookat: (bot, a) => { const p = findPlayer(a[0]); if (!p) return emit({ event: "error", msg: "player not found" }); bot.lookAtEntity(p); emit({ event: "ok", cmd: "lookat" }); },
  jump: (bot) => { bot.jump(); emit({ event: "ok", cmd: "jump" }); },
  hit: (bot) => { const ok = bot.attack(); emit({ event: "ok", cmd: "hit", hit: !!ok }); },   // one swing at whatever it looks at
  attack: (bot, a) => { setTask({ type: "attack", filter: (a[0] ?? "").toLowerCase().replace("minecraft:", ""), hits: 0 }, 20 * 60); emit({ event: "started", task: "attack", filter: a[0] ?? null }); },
  break: (bot, a, ctx) => {
    const r = readPos(a, 0, ctx); if (!r || a[0] === "me") return emit({ event: "error", msg: "usage: break x y z" });
    setTask({ type: "break", pos: flr(r.pos) }, 20 * 30); emit({ event: "started", task: "break", at: a.slice(0, 3).map(Number) });
  },
  place: (bot, a) => {
    const x = num(a[0]), y = num(a[1]), z = num(a[2]);
    if (x === null || y === null || z === null || !a[3]) return emit({ event: "error", msg: "usage: place x y z <block>" });
    const id = a[3].includes(":") ? a[3] : "minecraft:" + a[3];
    setTask({ type: "place", pos: { x: Math.floor(x), y: Math.floor(y), z: Math.floor(z) }, block: id }, 20 * 20);
    emit({ event: "started", task: "place", block: id });
  },
  use: (bot) => { bot.interact(); emit({ event: "ok", cmd: "use" }); },
  slot: (bot, a) => { const n = num(a[0]); if (n === null || n < 0 || n > 8) return emit({ event: "error", msg: "slot 0-8" }); bot.selectSlot(n); emit({ event: "ok", cmd: "slot", slot: n }); },
  give: (bot, a) => {   // debug / creative style helper
    const id = a[0] ? (a[0].includes(":") ? a[0] : "minecraft:" + a[0]) : null;
    if (!id) return emit({ event: "error", msg: "usage: give <item> [n]" });
    const ok = bot.giveItem(new ItemStack(id, Math.max(1, Math.min(64, num(a[1]) ?? 1))), false);
    emit({ event: "ok", cmd: "give", item: id, ok: !!ok });
  },
  say: (bot, a) => {
    const msg = a.join(" ");
    try { bot.chat(msg); } catch (_) { world.sendMessage(`<${S.name}> ${msg}`); }
    emit({ event: "ok", cmd: "say" });
  },
  tp: (bot, a, ctx) => { const r = readPos(a, 0, ctx); if (!r) return emit({ event: "error", msg: "usage: tp x y z | me" }); bot.teleport(r.pos); emit({ event: "ok", cmd: "tp" }); },
};

function run(line, ctx) {
  const a = line.trim().split(/\s+/); const cmd = (a.shift() ?? "").toLowerCase();
  try {
    if (C[cmd]) return C[cmd](a, ctx);
    if (B[cmd]) { if (!alive()) return emit({ event: "error", msg: "bot is not here, run: spawn" }); return B[cmd](S.sim, a, ctx); }
    emit({ event: "error", msg: "unknown command: " + cmd + " (try: help)" });
  } catch (e) { emit({ event: "error", cmd, msg: String(e) }); if (task && cmd === task.type) task = null; }
}

S.onTick = (bot) => {
  while (inbox.length) { const m = inbox.shift(); run(m.line, m.ctx); }
  try { applyInputs(bot, system.currentTick); } catch (e) { S.lastErr = "input: " + e; }
  if (task) { try { runTask(bot); } catch (e) { emit({ event: "error", task: task?.type, msg: String(e) }); task = null; } }
};

system.afterEvents.scriptEventReceive.subscribe(({ id, message, sourceEntity }) => {
  if (id !== "ai:cmd") return;
  const ctx = { src: sourceEntity && sourceEntity.typeId === "minecraft:player" ? sourceEntity : undefined };
  const first = (message ?? "").trim().split(/\s+/)[0].toLowerCase();
  if (alive() && !C[first]) inbox.push({ line: message ?? "", ctx });   // run inside the test loop
  else run(message ?? "", ctx);                                          // commands that do not need the bot yet (or errors)
});

emit({ event: "ready", hint: "/scriptevent ai:cmd spawn   then   /scriptevent ai:cmd help" });
