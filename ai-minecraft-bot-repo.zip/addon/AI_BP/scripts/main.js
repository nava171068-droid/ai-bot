// AI Player Bot - main.js : commands for the simulated player.   /scriptevent ai:cmd <command> [args]
// Every result is one JSON line  {"event":...}  written to the content log and (echo on) to chat as "[ai] {...}".
// A later bridge (e.g. the /connect 127.0.0.1:3000 app) only has to read those lines and send /scriptevent ai:cmd ... back.
import { world, system, Direction, ItemStack } from "@minecraft/server";
import { S, alive, requestSpawn, requestDespawn } from "./launcher.js";
import { scanBlocks, observe, inventory, backpack } from "./scan.js";
import { SAFE, probe, dirFrom, around } from "./safety.js";
import { SWIM, inWater, headUnder, findShore, waterInfo } from "./swim.js";

// transport = how result lines reach a /connect WebSocket client:  chat (world.sendMessage) | say (/say) | tellraw (/tellraw)
const cfg = { echo: true, transport: "chat" };
let chunkId = 0;
function emit(o) {
  let s; try { s = JSON.stringify(o); } catch (_) { s = String(o); }
  console.warn("[ai] " + s);
  if (!cfg.echo && cfg.transport !== "bot") return;
  try {
    if (cfg.transport === "bot") {
      // the simulated player says it in chat: a real chat line, so the /connect client gets it as PlayerMessage.
      // chat lines are short, so long JSON is cut into  [ai#id.i/n] pieces that the app glues together.
      if (!alive()) return;
      const CH = 170;
      if (s.length <= CH) { S.sim.chat("[ai] " + s); return; }
      const id = ++chunkId, n = Math.ceil(s.length / CH);
      for (let i = 0; i < n; i++) S.sim.chat("[ai#" + id + "." + i + "/" + n + "] " + s.slice(i * CH, (i + 1) * CH));
    } else if (cfg.transport === "say") world.getDimension("overworld").runCommand("say [ai] " + s);
    else if (cfg.transport === "tellraw") world.getDimension("overworld").runCommand("tellraw @a " + JSON.stringify({ rawtext: [{ text: "[ai] " + s }] }));
    else world.sendMessage("\u00a78[ai] " + s);
  } catch (_) {}
}

const inbox = [];         // commands waiting to run inside the test loop (SimulatedPlayer calls are made from there)
let task = null;          // the one long-running job (goto / follow / break / place / attack)
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z);
const num = (s) => { const n = Number(s); return Number.isFinite(n) ? n : null; };
const flr = (p) => ({ x: Math.floor(p.x), y: Math.floor(p.y), z: Math.floor(p.z) });
const realPlayers = () => world.getAllPlayers().filter((p) => !(S.sim && p.id === S.sim.id));
const findPlayer = (name) => realPlayers().find((p) => p.name.toLowerCase() === String(name).toLowerCase());

function releaseAll() { try { for (const k of BTN) delete held[k]; } catch (_) {} }
function finish(ok, msg) {
  if (!task) return;
  releaseAll(); try { S.sim.stopMoving(); } catch (_) {}
  const ch = task.chain;                       // a step of a bigger job (collect): hand over to it instead of reporting
  if (ch) { task = null; return ch.next(ok, msg); }
  emit({ event: "done", task: task.type, ok, msg }); task = null;
}
function setTask(t, ticks) { releaseAll(); if (task) emit({ event: "cancel", task: task.type }); task = { ...t, nextNav: 0, deadline: ticks ? system.currentTick + ticks : Infinity }; }

// "x y z" or "me" (the player who sent the command) -> position
function readPos(a, i, ctx) {
  if (a[i] === "me") { const p = ctx.src ?? realPlayers()[0]; return p ? { pos: { ...p.location }, used: 1 } : null; }
  const x = num(a[i]), y = num(a[i + 1]), z = num(a[i + 2]);
  return x === null || y === null || z === null ? null : { pos: { x, y, z }, used: 3 };
}

function nav(bot, pos, speed) {
  const r = bot.navigateToLocation(pos, speed);
  if (r && r.isFullPath === false && task && !task.warned) { task.warned = true; emit({ event: "warn", msg: "no full path, going as far as possible" }); }
}

// a free spot next to the block (feet + head room, solid floor) - never path INTO the solid block itself
function standSpot(dim, bot, pos) {
  let best = null, bd = 1e9;
  for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
    const x = pos.x + dx, z = pos.z + dz;
    for (const dy of [0, -1, 1]) {
      const y = pos.y + dy;
      let f, h, g;
      try { f = dim.getBlock({ x, y, z }); h = dim.getBlock({ x, y: y + 1, z }); g = dim.getBlock({ x, y: y - 1, z }); } catch (_) { continue; }
      if (!f || !h || !g || !isAir(f) || !isAir(h) || isAir(g) || g.isLiquid) continue;
      const d = dist(bot.location, { x: x + 0.5, y, z: z + 0.5 });
      if (d < bd) { bd = d; best = { x: x + 0.5, y, z: z + 0.5 }; }
    }
  }
  return best;
}

// walk until the target block is within reach; true when it is
function inReach(bot, pos, t, now) {
  const c = { x: pos.x + 0.5, y: pos.y + 0.5, z: pos.z + 0.5 };
  const e = bot.getHeadLocation ? bot.getHeadLocation() : bot.location;
  if (dist(e, c) <= 4.5) return true;
  if (now >= t.nextNav) { nav(bot, standSpot(bot.dimension, bot, pos) ?? c, 1); t.nextNav = now + 20; }
  return false;
}

const FACES = [[0, -1, 0, Direction.Up], [0, 1, 0, Direction.Down], [0, 0, 1, Direction.North], [0, 0, -1, Direction.South], [1, 0, 0, Direction.West], [-1, 0, 0, Direction.East]];
const isAir = (b) => !b || b.typeId === "minecraft:air" || b.typeId === "minecraft:cave_air";

function findTarget(bot, t) {
  let es = []; try { es = bot.dimension.getEntities({ location: bot.location, maxDistance: 16 }); } catch (_) {}
  let best = null, bd = 1e9;
  for (const e of es) {
    if (e.id === bot.id || e.typeId === "minecraft:item" || e.typeId === "minecraft:xp_orb") continue;
    if (e.typeId === "minecraft:player" && t.filter !== "player") continue;   // never attacks players unless asked by name of the type
    if (t.filter && !e.typeId.includes(t.filter)) continue;
    const d = dist(bot.location, e.location);
    if (d < bd) { bd = d; best = e; }
  }
  return best;
}

// ---------------------------------------------------------------- backpack: put an item in the right hand
const itemId = (s) => String(s ?? "").toLowerCase().replace("minecraft:", "");
// slot of an item by name (exact first, then part of the name); hotbar slots come first
function findItem(bot, q) {
  q = itemId(q); if (!q) return -1;
  let c; try { c = bot.getComponent("minecraft:inventory").container; } catch (_) { return -1; }
  let part = -1;
  for (let i = 0; i < c.size; i++) {
    const it = c.getItem(i); if (!it) continue;
    const id = itemId(it.typeId);
    if (id === q) return i;
    if (part < 0 && id.includes(q)) part = i;
  }
  return part;
}
// make `slot` the item in hand. Hotbar slot: just select it. Bag slot: move it into a free hotbar slot (or swap with the selected one). returns the hotbar slot
function holdSlot(bot, slot) {
  const c = bot.getComponent("minecraft:inventory").container;
  let sel = slot;
  if (slot > 8) {
    let free = -1; for (let i = 0; i < 9; i++) if (!c.getItem(i)) { free = i; break; }
    if (free >= 0) { c.moveItem(slot, free, c); sel = free; }
    else { sel = bot.selectedSlotIndex; c.swapItems(slot, sel, c); }
  }
  bot.selectSlot(sel);
  return sel;
}

// walk towards a WORLD direction (dx,dz) whatever way the bot currently faces: the direction is turned into forward/left
// amounts with the bot's real yaw, so walking still works when turning does not.
function walkWorld(bot, dx, dz, sprint) {
  const n = Math.hypot(dx, dz); if (n < 1e-6) return;
  dx /= n; dz /= n;
  let yaw = 0; try { yaw = bot.getRotation().y; } catch (_) {}
  const k = Math.PI / 180, s = Math.sin(yaw * k), c = Math.cos(yaw * k);
  bot.moveRelative(c * dx + s * dz, -s * dx + c * dz, sprint ? 1.4 : 1);   // (left, forward)
  moving = false;   // applyInputs must not cancel this move
}
// lava / cliff in the way of a world direction? true = the task was ended
function hazardProbe(bot, dx, dz) {
  if (!SAFE.on) return null;
  let g = true; try { g = bot.isOnGround; } catch (_) {}
  if (!g) return null;
  return probe(bot.dimension, bot.location, dx, dz, 2.5);
}
function hazardAhead(bot, dx, dz) {
  const h = hazardProbe(bot, dx, dz);
  if (!h) return false;
  danger(h, "stopped, " + h.hz + " ahead");
  finish(false, "danger: " + h.hz + " ahead");
  return true;
}

// ---------------------------------------------------------------- pick up dropped items
const PICK = { auto: true };   // auto: after mine_block / break the bot walks over and collects the drops
function nearestDrop(dim, loc, R, filter, skip) {
  let es = []; try { es = dim.getEntities({ type: "minecraft:item", location: loc, maxDistance: R }); } catch (_) {}
  let best = null, bd = 1e9;
  for (const e of es) {
    if (skip.includes(e.id)) continue;
    let l, it = null; try { l = e.location; it = e.getComponent("minecraft:item").itemStack; } catch (_) { continue; }
    if (filter && !(it && it.typeId.includes(filter))) continue;
    const d = Math.hypot(l.x - loc.x, l.y - loc.y, l.z - loc.z);
    if (d < bd) { bd = d; best = e; }
  }
  return best;
}
// turn the running task into a pickup of the drops around the bot (used when a block is gone)
function toPickup(t, now, note) { Object.assign(t, { type: "pickup", radius: 6, filter: "", got: 0, skip: [], target: null, note, deadline: now + 20 * 15 }); }

function runTask(bot) {
  const t = task, now = system.currentTick, loc = bot.location, dim = bot.dimension;
  if (now > t.deadline) { try { bot.stopMoving(); } catch (_) {} return finish(false, "timeout"); }
  switch (t.type) {
    case "goto": {
      if (dist(loc, t.pos) < 1.8) { bot.stopMoving(); return finish(true, "arrived"); }
      if (now >= t.nextNav) { nav(bot, t.pos, t.speed); t.nextNav = now + 20; }
      break;
    }
    case "follow": {
      const p = findPlayer(t.name);
      if (!p) return finish(false, "player not found");
      if (p.dimension.id !== dim.id) { bot.teleport(p.location, { dimension: p.dimension }); break; }
      const d = dist(loc, p.location);
      if (d > t.dist) { if (now >= t.nextNav) { bot.navigateToEntity(p, 1); t.nextNav = now + 10; t.moving = true; } }
      else if (t.moving) { bot.stopMoving(); t.moving = false; }
      break;
    }
    case "break": {
      const b = dim.getBlock(t.pos);
      if (isAir(b)) { if (PICK.auto) { toPickup(t, now, "broken"); break; } return finish(true, "broken"); }
      if (!inReach(bot, t.pos, t, now)) break;
      if (t.walking) { bot.stopMoving(); t.walking = false; }
      bot.lookAtBlock(t.pos);
      const hit = bot.breakBlock(t.pos);
      if (t.t0 === undefined) t.t0 = now;
      // survival mining by hand can stall (no progress even while looking at the block): after 5 s finish it with "destroy"
      if (now - t.t0 > 100 && !t.forced) {
        t.forced = true;
        try { dim.runCommand(`setblock ${t.pos.x} ${t.pos.y} ${t.pos.z} air destroy`); } catch (_) {}
        emit({ event: "warn", msg: "breakBlock made no progress (last=" + hit + "), used destroy fallback" });
      }
      break;
    }
    case "place": {
      const b = dim.getBlock(t.pos);
      if (b && b.typeId === t.block) return finish(true, "placed");
      if (!t.tried) {
        if (!isAir(b) && !(b && b.isLiquid)) return finish(false, "target not empty: " + b.typeId);
        if (!inReach(bot, t.pos, t, now)) break;
        const { slots } = inventory(bot);
        const it = slots.find((s) => "minecraft:" + s[1] === t.block || s[1] === t.block.replace("minecraft:", ""));
        if (!it) return finish(false, "item not in inventory: " + t.block);
        try { holdSlot(bot, it[0]); } catch (e) { return finish(false, "cannot hold the item: " + e); }
        const f = FACES.find(([dx, dy, dz]) => { const n = dim.getBlock({ x: t.pos.x + dx, y: t.pos.y + dy, z: t.pos.z + dz }); return n && !isAir(n) && !n.isLiquid; });
        if (!f) return finish(false, "no solid block next to the target");
        const nb = { x: t.pos.x + f[0], y: t.pos.y + f[1], z: t.pos.z + f[2] };
        bot.stopMoving(); bot.lookAtBlock(nb);
        bot.interactWithBlock(nb, f[3]);
        t.tried = now; t.retry = (t.retry ?? 0) + 1;
      } else if (now - t.tried > 10) {
        if (t.retry >= 3) return finish(false, "place failed");
        t.tried = 0;
      }
      break;
    }
    case "walkto": {      // walk to the block (no pathfinding): moves in the world direction of the target, jumps when stuck
      const dx = t.pos.x + 0.5 - loc.x, dz = t.pos.z + 0.5 - loc.z;
      if (Math.hypot(dx, dz) < 1.2) return finish(true, "arrived");
      aim(bot, Math.atan2(-dx, dz) * 180 / Math.PI, 0);
      if (hazardAhead(bot, dx, dz)) return;
      walkWorld(bot, dx, dz);
      if (now >= t.chk) {
        if (Math.hypot(loc.x - t.lx, loc.z - t.lz) < 0.3) { held.jump = now + 10; if (++t.stuck > 8) return finish(false, "stuck, something blocks the way"); } else t.stuck = 0;
        t.lx = loc.x; t.lz = loc.z; t.chk = now + 20;
      }
      break;
    }
    case "mineat": {      // walk next to the block, look at it, hold mine until it is gone
      if (isAir(dim.getBlock(t.pos))) { if (PICK.auto) { toPickup(t, now, "broken"); break; } return finish(true, "broken"); }
      const e = bot.getHeadLocation();
      const dx = t.pos.x + 0.5 - e.x, dy = t.pos.y + 0.5 - e.y, dz = t.pos.z + 0.5 - e.z, h = Math.hypot(dx, dz), d = Math.hypot(h, dy);
      aim(bot, Math.atan2(-dx, dz) * 180 / Math.PI, Math.max(-89, Math.min(89, -Math.atan2(dy, h) * 180 / Math.PI)));
      if (d > 3.8) {
        delete held.mine; t.walk = true;
        if (hazardAhead(bot, dx, dz)) return;
        walkWorld(bot, dx, dz);
        if (now >= t.chk) {
          if (Math.hypot(loc.x - t.lx, loc.z - t.lz) < 0.3) { held.jump = now + 10; if (++t.stuck > 8) return finish(false, "stuck, cannot get close"); } else t.stuck = 0;
          t.lx = loc.x; t.lz = loc.z; t.chk = now + 20;
        }
      } else {
        if (t.walk) { bot.stopMoving(); t.walk = false; }
        delete held.mine;
        // break the block directly by position (does not need the crosshair to be on it); call it every tick until it is gone
        try { bot.lookAtBlock(t.pos); } catch (_) {}
        let hit = false; try { hit = bot.breakBlock(t.pos); } catch (e) { t.err = String(e); }
        if (t.t0 === undefined) t.t0 = now;
        // mining by hand can stall: after 5 s of trying finish it with "destroy" (same fallback as the break task)
        if (now - t.t0 > 100 && !t.forced) {
          t.forced = true;
          try { dim.runCommand(`setblock ${t.pos.x} ${t.pos.y} ${t.pos.z} air destroy`); } catch (_) {}
          emit({ event: "warn", msg: "breakBlock made no progress (last=" + hit + (t.err ? ", err=" + t.err : "") + "), used destroy fallback" });
        }
      }
      break;
    }
    case "swim": {        // swim to the shore (or to x y z): float up, sprint-swim towards the target, done when out of the water
      if (!inWater(bot)) return finish(true, "out of the water" + (t.pos ? " at " + t.pos.x + " " + t.pos.y + " " + t.pos.z : ""));
      if (t.t0 === undefined) t.t0 = now;
      if (!t.fixed && now >= (t.refind ?? 0)) {
        t.refind = now + 20;
        const s = findShore(dim, loc, 16);
        if (s) t.pos = { x: s.x, y: s.y, z: s.z };
        else if (!t.warnedNo) { t.warnedNo = true; emit({ event: "warn", msg: "no shore within 16 blocks, floating" }); }
      }
      try { bot.jump(); } catch (_) {}                       // holding jump in water = swim up / stay on the surface
      if (!t.pos) break;
      const dx = t.pos.x + 0.5 - loc.x, dz = t.pos.z + 0.5 - loc.z;
      aim(bot, Math.atan2(-dx, dz) * 180 / Math.PI, 0);
      try { bot.isSprinting = true; } catch (_) {}            // sprint in water = swimming
      walkWorld(bot, dx, dz, true);
      // still in the water after 15 s: the swim buttons did not work, put the bot on the shore so it does not drown
      if (now - t.t0 > 300 && !t.forced) {
        t.forced = true;
        try { bot.teleport({ x: t.pos.x + 0.5, y: t.pos.y, z: t.pos.z + 0.5 }, { keepVelocity: false }); } catch (_) {}
        emit({ event: "warn", msg: "swimming made no progress, moved the bot to the shore" });
      }
      break;
    }
    case "pickup": {      // walk to the nearest dropped item until it is picked up, repeat until none is left
      let tg = t.target;
      if (tg) { let ok = true; try { ok = tg.isValid; } catch (_) { ok = false; } if (!ok) { if ((t.lastD ?? 9) < 2.5) t.got++; tg = t.target = null; } }
      if (!tg) {
        tg = nearestDrop(dim, loc, t.radius ?? 10, t.filter ?? "", t.skip);
        if (!tg) return finish(true, (t.note ? t.note + "; " : "") + (t.got ? "picked up " + t.got + " item(s)" : "no drops to pick up"));
        t.target = tg; t.stuck = 0; t.near = 0; t.lx = loc.x; t.lz = loc.z; t.chk = now + 20;
      }
      let p; try { p = tg.location; } catch (_) { t.target = null; break; }
      const dx = p.x - loc.x, dz = p.z - loc.z, h = Math.hypot(dx, dz);
      t.lastD = Math.hypot(h, p.y - loc.y);
      if (h < 0.7) {      // on top of it: the game pulls it in after a moment
        try { bot.stopMoving(); } catch (_) {}
        if (++t.near > 40) { t.skip.push(tg.id); t.target = null; emit({ event: "warn", msg: "could not pick the item up (inventory full?)" }); }
        break;
      }
      t.near = 0;
      const hz = hazardProbe(bot, dx, dz);
      if (hz) { t.skip.push(tg.id); t.target = null; danger(hz, "skipped a drop, " + hz.hz + " in the way"); break; }
      aim(bot, Math.atan2(-dx, dz) * 180 / Math.PI, 0);
      walkWorld(bot, dx, dz);
      if (now >= t.chk) {
        if (Math.hypot(loc.x - t.lx, loc.z - t.lz) < 0.3) { held.jump = now + 10; if (++t.stuck > 6) { t.skip.push(tg.id); t.target = null; } } else t.stuck = 0;
        t.lx = loc.x; t.lz = loc.z; t.chk = now + 20;
      }
      break;
    }
    case "attack": {
      if (!t.target || !t.target.isValid) {
        t.target = findTarget(bot, t);
        if (!t.target) return finish(t.hits > 0, t.hits > 0 ? "no target left" : "no target nearby");
      }
      const e = t.target, d = dist(loc, e.location);
      if (d > 2.8) { if (now >= t.nextNav) { bot.navigateToEntity(e, 1.2); t.nextNav = now + 10; } }
      else { bot.stopMoving(); bot.lookAtEntity(e); if (now >= (t.nextHit ?? 0)) { bot.attackEntity(e); t.nextHit = now + 12; t.hits = (t.hits ?? 0) + 1; } }
      break;
    }
  }
}

// ---------------------------------------------------------------- "buttons": what a player's fingers do
// A held button stays on until its timer ends (or release). Applied every tick inside the test loop.
const BTN = ["forward", "back", "left", "right", "jump", "sneak", "sprint", "mine", "attack"];
const held = {};                 // button -> tick when it lets go (Infinity = until release)
let moving = false, mining = false, nextHit = 0;
const heldList = () => BTN.filter((b) => held[b]);
const stopMine = (bot) => { if (mining) { try { bot.stopBreakingBlock(); } catch (_) {} mining = false; } };

// ---------------------------------------------------------------- safety: do not walk into lava / off a cliff
let blockedNow = null, nextDanger = 0, lastPos = null;
function danger(h, how) {
  const now = system.currentTick;
  if (now < nextDanger) return;
  nextDanger = now + 20;
  emit({ event: "danger", hz: h.hz, d: h.d, at: h.at, msg: how });
}
// buttons: look where the pressed buttons would take the bot (only while it stands on the ground)
function guardButtons(bot, fb, lr) {
  if (!SAFE.on) return null;
  let g = true; try { g = bot.isOnGround; } catch (_) {}
  if (!g) return null;
  let yaw; try { yaw = bot.getRotation().y; } catch (_) { return null; }
  const [dx, dz] = dirFrom(yaw, fb, lr);
  const h = probe(bot.dimension, bot.location, dx, dz, held.sprint ? 3.5 : 2.5);
  if (h) danger(h, "stopped, " + h.hz + " ahead");
  return h;
}
// goto / follow / attack ...: the pathfinder moves the bot, so look along the way it actually moved this tick
const NAV = new Set(["goto", "follow", "attack", "break", "place"]);
function guardNav(bot) {
  const l = bot.location, prev = lastPos; lastPos = { x: l.x, y: l.y, z: l.z };
  if (!SAFE.on || !task || !NAV.has(task.type) || !prev) return;
  const dx = l.x - prev.x, dz = l.z - prev.z;
  if (Math.hypot(dx, dz) < 0.02) return;
  let g = true; try { g = bot.isOnGround; } catch (_) {}
  if (!g) return;
  const h = probe(bot.dimension, l, dx, dz, 2);
  if (!h) return;
  try { bot.stopMoving(); } catch (_) {}
  danger(h, "path stopped, " + h.hz + " ahead");
  finish(false, "danger: " + h.hz + " ahead");
}

// ---------------------------------------------------------------- collect: find the nearest block of a kind, mine it, pick up, repeat (one command, no LLM round trip between blocks)
function findNearestBlock(dim, from, q, r, skip) {
  const cx = Math.floor(from.x), cy = Math.floor(from.y), cz = Math.floor(from.z);
  let lo = -1e9, hi = 1e9; try { const hr = dim.heightRange; lo = hr.min; hi = hr.max - 1; } catch (_) {}
  let best = null, bs = 1e9;
  for (let dx = -r; dx <= r; dx++) for (let dz = -r; dz <= r; dz++) for (let dy = -3; dy <= 7; dy++) {
    const x = cx + dx, y = cy + dy, z = cz + dz;
    if (y < lo || y > hi || skip.has(x + "," + y + "," + z)) continue;
    let b; try { b = dim.getBlock({ x, y, z }); } catch (_) { continue; }
    if (!b || b.isLiquid || !b.typeId.includes(q)) continue;
    const s = Math.hypot(dx, dz) + Math.abs(dy) * 0.8 + (dy > 0 ? dy * 0.4 : 0);   // near first, low first
    if (s < bs) { bs = s; best = { x, y, z }; }
  }
  return best;
}
function nextCollect(bot, ch) {
  if (ch.got >= ch.n) return emit({ event: "done", task: "collect", ok: true, msg: "collected " + ch.got + " " + ch.q });
  if (ch.fail >= 3) return emit({ event: "done", task: "collect", ok: ch.got > 0, msg: "collected " + ch.got + " " + ch.q + ", gave up after 3 failed blocks (" + ch.last + ")" });
  const t = findNearestBlock(bot.dimension, bot.location, ch.q, 14, ch.skip);
  if (!t) return emit({ event: "done", task: "collect", ok: ch.got > 0, msg: ch.got ? "collected " + ch.got + " " + ch.q + ", no more within 14 blocks" : "no " + ch.q + " within 14 blocks" });
  ch.skip.add(t.x + "," + t.y + "," + t.z);
  const now = system.currentTick;
  task = { type: "mineat", pos: t, lx: bot.location.x, lz: bot.location.z, chk: now + 20, stuck: 0, nextNav: 0, deadline: now + 20 * 40, chain: ch };
}
function startCollect(bot, q, n) {
  releaseAll();
  const ch = { q, n, got: 0, fail: 0, last: "", skip: new Set(), next: null };
  ch.next = (ok, msg) => { if (ok) ch.got++; else { ch.fail++; ch.last = msg; } try { nextCollect(S.sim, ch); } catch (e) { emit({ event: "done", task: "collect", ok: false, msg: String(e) }); } };
  nextCollect(bot, ch);
}

// ---------------------------------------------------------------- reflexes: things a player does without thinking (fight a nearby monster, eat when hurt)
// They run inside the game, every few ticks, with no LLM round trip. The AI is told what happened (event "reflex") and decides what to do next.
const RX = { on: true, fight: null, rescan: 0, nextHit: 0, kills: 0, eatAt: 0, eatUntil: 0, eatSlot: -1, hpLow: 14, range: 8 };
const NO_FIGHT = new Set(["minecraft:enderman", "minecraft:zombified_piglin", "minecraft:piglin", "minecraft:iron_golem"]);   // only hit these if the AI orders it
const FOOD = ["cooked_beef", "cooked_porkchop", "cooked_mutton", "cooked_chicken", "cooked_salmon", "cooked_cod", "baked_potato", "bread", "pumpkin_pie", "golden_carrot", "carrot", "apple", "melon_slice", "cookie", "beetroot", "sweet_berries"];
function bestWeaponSlot(bot) {
  try {
    const c = bot.getComponent("minecraft:inventory").container;
    let sw = -1, ax = -1;
    for (let i = 0; i < c.size; i++) { const it = c.getItem(i); if (!it) continue; const id = it.typeId; if (id.endsWith("_sword")) sw = i; else if (id.endsWith("_axe") && ax < 0) ax = i; }
    return sw >= 0 ? sw : ax;
  } catch (_) { return -1; }
}
function foodSlot(bot) {
  try {
    const c = bot.getComponent("minecraft:inventory").container;
    let best = -1, rank = 1e9;
    for (let i = 0; i < c.size; i++) { const it = c.getItem(i); if (!it) continue; const k = FOOD.indexOf(itemId(it.typeId)); if (k >= 0 && k < rank) { rank = k; best = i; } }
    return best;
  } catch (_) { return -1; }
}
function nearestMonster(bot, range) {
  let es = []; try { es = bot.dimension.getEntities({ location: bot.location, maxDistance: range, families: ["monster"] }); } catch (_) { return null; }
  let best = null, bd = 1e9;
  for (const e of es) {
    if (e.id === bot.id || NO_FIGHT.has(e.typeId)) continue;
    let l; try { l = e.location; } catch (_) { continue; }
    const d = dist(bot.location, l);
    if (d < bd) { bd = d; best = e; }
  }
  return best;
}
// returns true while the bot is busy fighting (the caller then skips the normal inputs / task for this tick)
function reflexTick(bot, now) {
  if (!RX.on) return false;
  let tg = RX.fight;
  if (tg) { let ok = false; try { ok = tg.isValid; } catch (_) {} if (!ok) { RX.kills++; tg = RX.fight = null; RX.rescan = 0; } }
  if (!tg && now >= RX.rescan) { RX.rescan = now + 10; tg = nearestMonster(bot, RX.range); }
  if (!tg) {
    if (RX.fight === null && RX.wasFighting) { RX.wasFighting = false; emit({ event: "reflex", what: "fight_end", kills: RX.kills, hp: hpOf(bot) }); }
    // eat when hurt
    if (RX.eatUntil > now) { try { bot.useItemInSlot(RX.eatSlot); } catch (_) { try { bot.interact(); } catch (_) {} } return false; }
    const hp = hpOf(bot);
    if (hp !== null && hp > 0 && hp <= RX.hpLow && now >= RX.eatAt) {
      RX.eatAt = now + 100;
      const s = foodSlot(bot);
      if (s >= 0) {
        try { RX.eatSlot = holdSlot(bot, s); RX.eatUntil = now + 40; emit({ event: "reflex", what: "eat", hp, item: itemId(bot.getComponent("minecraft:inventory").container.getItem(RX.eatSlot)?.typeId) }); } catch (_) {}
      } else if (now >= (RX.noFoodAt ?? 0)) { RX.noFoodAt = now + 600; emit({ event: "reflex", what: "hurt_no_food", hp }); }
    }
    return false;
  }
  if (!RX.wasFighting) {                      // fight starts: drop whatever the bot was doing, grab a weapon, tell the AI
    RX.wasFighting = true; RX.kills = 0;
    for (const k of BTN) delete held[k];
    if (task) { emit({ event: "done", task: task.type, ok: false, msg: "interrupted: fighting " + tg.typeId.replace("minecraft:", "") }); task = null; }
    try { bot.stopMoving(); } catch (_) {}
    const w = bestWeaponSlot(bot); if (w >= 0) { try { holdSlot(bot, w); } catch (_) {} }
    emit({ event: "reflex", what: "fight_start", mob: tg.typeId.replace("minecraft:", ""), d: Math.round(dist(bot.location, tg.location) * 10) / 10, hp: hpOf(bot) });
  } else if (task) { emit({ event: "done", task: task.type, ok: false, msg: "interrupted: fighting" }); task = null; }
  RX.fight = tg;
  let l; try { l = tg.location; } catch (_) { RX.fight = null; return false; }
  const loc = bot.location, dx = l.x - loc.x, dz = l.z - loc.z, d = dist(loc, l);
  if (d > 12) { RX.fight = null; return false; }   // ran away
  if (d > 2.6) {
    if (hazardProbe(bot, dx, dz)) { try { bot.stopMoving(); } catch (_) {} return true; }   // do not chase it over a cliff / into lava
    aim(bot, Math.atan2(-dx, dz) * 180 / Math.PI, 0);
    walkWorld(bot, dx, dz, true);
  } else {
    try { bot.stopMoving(); } catch (_) {}
    try { bot.lookAtEntity(tg); } catch (_) {}
    if (now >= RX.nextHit) { try { bot.attackEntity(tg); } catch (_) {} RX.nextHit = now + 12; }
  }
  return true;
}

function applyInputs(bot, now) {
  for (const k of BTN) if (held[k] && now > held[k]) delete held[k];
  const fb = (held.forward ? 1 : 0) - (held.back ? 1 : 0);
  const lr = (held.left ? 1 : 0) - (held.right ? 1 : 0);
  blockedNow = null;
  if (fb || lr) {
    const h = guardButtons(bot, fb, lr);
    if (h) {          // lava / drop ahead: do not move, let go of the walking buttons
      blockedNow = h.hz;
      bot.stopMoving(); moving = false;
      for (const m of ["forward", "back", "left", "right", "sprint"]) delete held[m];
    } else { bot.moveRelative(lr, fb, held.sprint ? 1.4 : 1); moving = true; }
  }
  else if (moving) { bot.stopMoving(); moving = false; }
  try { bot.isSneaking = !!held.sneak; } catch (_) {}
  try { bot.isSprinting = !!held.sprint && fb > 0; } catch (_) {}
  if (held.jump) { let g = true; try { g = bot.isOnGround; } catch (_) {} if (g) bot.jump(); }
  if (held.mine) {
    let h = null; try { h = bot.getBlockFromViewDirection({ maxDistance: 5.5 }); } catch (_) {}
    if (h && h.block && !isAir(h.block)) { bot.breakBlock(h.block.location, h.face); mining = true; }
    else stopMine(bot);
  } else stopMine(bot);
  if (held.attack && now >= nextHit) { try { bot.attack(); } catch (_) {} nextHit = now + 12; }
}

// face a yaw/pitch (degrees): aim at a far point along that direction
function aim(bot, yaw, pitch) {
  yaw = ((yaw + 180) % 360 + 360) % 360 - 180;
  try { bot.setRotation({ x: pitch, y: yaw }); return; } catch (_) {}   // exact turn
  const k = Math.PI / 180, e = bot.getHeadLocation();
  bot.lookAtLocation({ x: e.x - Math.sin(yaw * k) * Math.cos(pitch * k) * 10, y: e.y - Math.sin(pitch * k) * 10, z: e.z + Math.cos(yaw * k) * Math.cos(pitch * k) * 10 });
}

// ---------------------------------------------------------------- commands
const HELP = "spawn [name] | despawn | status | obs | inv | scan [r] [filter] | find <block> [r] | goto x y z|me [speed] | follow <player|me> [dist] | stop | " +
  "walkto x y z | mineat x y z | collect <block> [n] | reflex [on|off|hp N] | safe [on|off|drop n] | swim [x y z|auto on|off] | backpack | equip <item|slot> | pickup [r] [item|auto on|off] | hold <button> [sec] | release [button|all] | tap jump|use|attack | turn dyaw dpitch | look x y z|me | lookat <player> | jump | attack [type] | hit | break x y z | place x y z <block> | use | slot <0-8> | give <item> [n] | say <text> | tp x y z|me | echo on|off | transport bot|chat|say|tellraw | ping";

const C = {
  help: () => emit({ event: "help", cmds: HELP }),
  status: () => emit({ event: "status", v: "0.10.0", alive: alive(), want: S.want, name: S.name, via: S.via, gametest: !!S.gt, task: task?.type ?? null, err: S.gtErr || S.lastErr || null }),
  spawn: (a, ctx) => {
    const p = ctx.src ?? realPlayers()[0];
    const at = p ? { x: p.location.x + 1.5, y: p.location.y, z: p.location.z + 1.5 } : undefined;
    requestSpawn(a[0], at, p ? p.dimension.id.replace("minecraft:", "") : undefined);
    emit({ event: "spawning", name: S.name });
  },
  despawn: () => { task = null; requestDespawn(); emit({ event: "despawning" }); },
  ping: () => emit({ event: "pong", t: system.currentTick }),
  transport: (a) => { if (["chat", "say", "tellraw", "bot"].includes(a[0])) cfg.transport = a[0]; emit({ event: "transport", mode: cfg.transport }); },
  echo: (a) => { cfg.echo = a[0] !== "off"; emit({ event: "echo", on: cfg.echo }); },
};
const B = {   // need a living bot
  obs: (bot) => emit({ ...observe(bot, task), held: heldList(), around: SAFE.on ? around(bot) : undefined, water: waterInfo(bot) }),   // around = ground/lava check in 4 directions (ok | lava@2 | drop@1 ...)
  walkto: (bot, a, ctx) => {   // walkto x y z | me   (button macro)
    const r = readPos(a, 0, ctx); if (!r) return emit({ event: "error", msg: "usage: walkto x y z | me" });
    setTask({ type: "walkto", pos: flr(r.pos), lx: bot.location.x, lz: bot.location.z, chk: system.currentTick + 20, stuck: 0 }, 20 * 45);
    emit({ event: "started", task: "walkto", to: [Math.floor(r.pos.x), Math.floor(r.pos.y), Math.floor(r.pos.z)] });
  },
  mineat: (bot, a, ctx) => {   // mineat x y z   (button macro: walk close, look, hold mine)
    const r = readPos(a, 0, ctx); if (!r || a[0] === "me") return emit({ event: "error", msg: "usage: mineat x y z" });
    setTask({ type: "mineat", pos: flr(r.pos), lx: bot.location.x, lz: bot.location.z, chk: system.currentTick + 20, stuck: 0 }, 20 * 40);
    emit({ event: "started", task: "mineat", at: [Math.floor(r.pos.x), Math.floor(r.pos.y), Math.floor(r.pos.z)] });
  },
  pickup: (bot, a) => {    // pickup [radius] [item]  |  pickup auto on|off
    if ((a[0] ?? "").toLowerCase() === "auto") { PICK.auto = a[1] !== "off"; return emit({ event: "ok", cmd: "pickup", auto: PICK.auto }); }
    const r = num(a[0]), filter = itemId(r !== null ? a[1] : a[0]);
    setTask({ type: "pickup", radius: Math.max(2, Math.min(24, r ?? 10)), filter, got: 0, skip: [], target: null }, 20 * 40);
    emit({ event: "started", task: "pickup", filter: filter || null });
  },
  backpack: (bot) => emit(backpack(bot)),
  collect: (bot, a) => {   // collect <block> [n]   find the nearest such block, mine it, pick up the drops, repeat n times (default 1)
    const q = itemId(a[0]); if (!q) return emit({ event: "error", msg: "usage: collect <block e.g. log|iron_ore|stone> [count]" });
    const n = Math.max(1, Math.min(32, Math.floor(num(a[1]) ?? 1)));
    if (task) { emit({ event: "cancel", task: task.type }); task = null; }
    emit({ event: "started", task: "collect", block: q, n });
    startCollect(bot, q, n);
  },
  reflex: (bot, a) => {    // reflex [on|off] [hp N]   fight nearby monsters / eat when hurt, by itself
    const v = (a[0] ?? "").toLowerCase();
    if (v === "on") RX.on = true; else if (v === "off") RX.on = false;
    if (v === "hp" && num(a[1]) !== null) RX.hpLow = Math.max(1, Math.min(19, num(a[1])));
    emit({ event: "reflex_cfg", on: RX.on, eat_below_hp: RX.hpLow, range: RX.range, fighting: !!RX.fight });
  },
  equip: (bot, a) => {     // equip <item name | slot>   put it in the right hand (bag items move to the hotbar)
    if (!a[0]) return emit({ event: "error", msg: "usage: equip <item name | slot>" });
    const n = num(a[0]);
    let slot = n !== null && Number.isInteger(n) ? n : findItem(bot, a[0]);
    let it = null; try { it = slot >= 0 ? bot.getComponent("minecraft:inventory").container.getItem(slot) : null; } catch (_) {}
    if (!it) return emit({ event: "error", msg: "not in the backpack: " + a[0] + " (call backpack to see what you have)" });
    let sel; try { sel = holdSlot(bot, slot); } catch (e) { return emit({ event: "error", msg: "cannot hold it: " + e }); }
    const id = it.typeId.replace("minecraft:", "");
    emit({ event: "ok", cmd: "equip", item: id, slot: sel, msg: "holding " + id + " x" + it.amount + " (hotbar slot " + sel + ")" });
  },
  safe: (bot, a) => {      // safe [on|off|drop <blocks>]  - lava / cliff guard
    const v = (a[0] ?? "").toLowerCase();
    if (v === "on") SAFE.on = true; else if (v === "off") SAFE.on = false;
    else if (v === "drop" && num(a[1]) !== null) SAFE.maxDrop = Math.max(1, Math.min(20, Math.floor(num(a[1]))));
    emit({ event: "safe", on: SAFE.on, maxDrop: SAFE.maxDrop, around: around(bot) });
  },
  swim: (bot, a, ctx) => {   // swim [x y z]  (no position = nearest shore)  |  swim auto on|off
    if ((a[0] ?? "").toLowerCase() === "auto") { SWIM.auto = a[1] !== "off"; return emit({ event: "ok", cmd: "swim", auto: SWIM.auto }); }
    const r = a.length >= 3 ? readPos(a, 0, ctx) : null;
    setTask({ type: "swim", pos: r ? flr(r.pos) : null, fixed: !!r, refind: 0 }, 20 * 40);
    emit({ event: "started", task: "swim", to: r ? [Math.floor(r.pos.x), Math.floor(r.pos.y), Math.floor(r.pos.z)] : "nearest shore" });
  },
  hold: (bot, a) => {      // hold <button> [seconds]   (no seconds = until release)
    const b = (a[0] ?? "").toLowerCase();
    if (!BTN.includes(b)) return emit({ event: "error", msg: "usage: hold <" + BTN.join("|") + "> [seconds]" });
    const sec = num(a[1]);
    if (task) { emit({ event: "cancel", task: task.type }); task = null; }
    held[b] = sec === null || sec <= 0 ? Infinity : system.currentTick + Math.round(Math.min(sec, 30) * 20);
    emit({ event: "ok", cmd: "hold", button: b, seconds: sec });
  },
  release: (bot, a) => {   // release [button|all]
    const b = (a[0] ?? "all").toLowerCase();
    if (b === "all") for (const k of BTN) delete held[k]; else delete held[b];
    emit({ event: "ok", cmd: "release", button: b });
  },
  tap: (bot, a) => {       // tap jump | use | attack
    const b = (a[0] ?? "").toLowerCase();
    if (b === "jump") bot.jump(); else if (b === "use") bot.interact(); else if (b === "attack") bot.attack();
    else return emit({ event: "error", msg: "usage: tap jump|use|attack" });
    emit({ event: "ok", cmd: "tap", button: b });
  },
  turn: (bot, a) => {      // turn <dyaw> <dpitch>   degrees, relative (yaw + = turn right / clockwise, pitch + = look down)
    const dy = num(a[0]) ?? 0, dp = num(a[1]) ?? 0;
    const r = bot.getRotation(), yaw = r.y + dy, pitch = Math.max(-89, Math.min(89, r.x + dp));
    aim(bot, yaw, pitch);
    emit({ event: "ok", cmd: "turn", yaw: Math.round(yaw), pitch: Math.round(pitch) });
  },
  inv: (bot) => emit({ event: "inv", ...inventory(bot) }),
  scan: (bot, a) => {
    const r = a[0] !== undefined && num(a[0]) !== null ? num(a[0]) : 6;
    const filter = num(a[0]) !== null ? a[1] : a[0];
    emit(scanBlocks(bot.dimension, bot.location, r, filter ?? ""));
  },
  find: (bot, a) => emit(scanBlocks(bot.dimension, bot.location, num(a[1]) ?? 10, a[0] ?? "", null, 10)),
  goto: (bot, a, ctx) => {
    const r = readPos(a, 0, ctx); if (!r) return emit({ event: "error", msg: "usage: goto x y z | me [speed]" });
    setTask({ type: "goto", pos: r.pos, speed: num(a[r.used]) ?? 1 }, 20 * 60);
    emit({ event: "started", task: "goto", to: [r.pos.x, r.pos.y, r.pos.z] });
  },
  follow: (bot, a, ctx) => {
    const name = a[0] === "me" || !a[0] ? (ctx.src ?? realPlayers()[0])?.name : a[0];
    if (!name) return emit({ event: "error", msg: "usage: follow <player|me> [dist]" });
    setTask({ type: "follow", name, dist: num(a[1]) ?? 3 });
    emit({ event: "started", task: "follow", name });
  },
  stop: (bot) => { try { bot.stopMoving(); } catch (_) {} for (const k of BTN) delete held[k]; const t = task; task = null; emit({ event: "stopped", task: t?.type ?? null }); },
  look: (bot, a, ctx) => {
    const r = readPos(a, 0, ctx); if (!r) return emit({ event: "error", msg: "usage: look x y z | me" });
    const e = bot.getHeadLocation(), dx = r.pos.x - e.x, dy = r.pos.y - e.y, dz = r.pos.z - e.z;
    const yaw = Math.atan2(-dx, dz) * 180 / Math.PI, pitch = -Math.atan2(dy, Math.hypot(dx, dz)) * 180 / Math.PI;
    aim(bot, yaw, Math.max(-89, Math.min(89, pitch)));
    emit({ event: "ok", cmd: "look", yaw: Math.round(yaw), pitch: Math.round(pitch) });
  },
  lookat: (bot, a) => { const p = findPlayer(a[0]); if (!p) return emit({ event: "error", msg: "player not found" }); bot.lookAtEntity(p); emit({ event: "ok", cmd: "lookat" }); },
  jump: (bot) => { bot.jump(); emit({ event: "ok", cmd: "jump" }); },
  hit: (bot) => { const ok = bot.attack(); emit({ event: "ok", cmd: "hit", hit: !!ok }); },   // one swing at whatever it looks at
  attack: (bot, a) => { setTask({ type: "attack", filter: (a[0] ?? "").toLowerCase().replace("minecraft:", ""), hits: 0 }, 20 * 60); emit({ event: "started", task: "attack", filter: a[0] ?? null }); },
  break: (bot, a, ctx) => {
    const r = readPos(a, 0, ctx); if (!r || a[0] === "me") return emit({ event: "error", msg: "usage: break x y z" });
    setTask({ type: "break", pos: flr(r.pos) }, 20 * 30); emit({ event: "started", task: "break", at: a.slice(0, 3).map(Number) });
  },
  place: (bot, a) => {
    const x = num(a[0]), y = num(a[1]), z = num(a[2]);
    if (x === null || y === null || z === null || !a[3]) return emit({ event: "error", msg: "usage: place x y z <block>" });
    const id = a[3].includes(":") ? a[3] : "minecraft:" + a[3];
    setTask({ type: "place", pos: { x: Math.floor(x), y: Math.floor(y), z: Math.floor(z) }, block: id }, 20 * 20);
    emit({ event: "started", task: "place", block: id });
  },
  use: (bot) => { bot.interact(); emit({ event: "ok", cmd: "use" }); },
  slot: (bot, a) => { const n = num(a[0]); if (n === null || n < 0 || n > 8) return emit({ event: "error", msg: "slot 0-8" }); bot.selectSlot(n); emit({ event: "ok", cmd: "slot", slot: n }); },
  give: (bot, a) => {   // debug / creative style helper
    const id = a[0] ? (a[0].includes(":") ? a[0] : "minecraft:" + a[0]) : null;
    if (!id) return emit({ event: "error", msg: "usage: give <item> [n]" });
    const ok = bot.giveItem(new ItemStack(id, Math.max(1, Math.min(64, num(a[1]) ?? 1))), false);
    emit({ event: "ok", cmd: "give", item: id, ok: !!ok });
  },
  say: (bot, a) => {
    const msg = a.join(" ");
    try { bot.chat(msg); } catch (_) { world.sendMessage(`<${S.name}> ${msg}`); }
    emit({ event: "ok", cmd: "say" });
  },
  tp: (bot, a, ctx) => { const r = readPos(a, 0, ctx); if (!r) return emit({ event: "error", msg: "usage: tp x y z | me" }); bot.teleport(r.pos); emit({ event: "ok", cmd: "tp" }); },
};

function run(line, ctx) {
  const a = line.trim().split(/\s+/); const cmd = (a.shift() ?? "").toLowerCase();
  try {
    if (C[cmd]) return C[cmd](a, ctx);
    if (B[cmd]) { if (!alive()) return emit({ event: "error", msg: "bot is not here, run: spawn" }); return B[cmd](S.sim, a, ctx); }
    emit({ event: "error", msg: "unknown command: " + cmd + " (try: help)" });
  } catch (e) { emit({ event: "error", cmd, msg: String(e) }); if (task && cmd === task.type) task = null; }
}

// ---------------------------------------------------------------- death: respawn by itself and come back to a player
let deadAt = 0;
const hpOf = (bot) => { try { return bot.getComponent("minecraft:health").currentValue; } catch (_) { return null; } };
function handleDeath(bot, now) {
  const hp = hpOf(bot);
  if (!deadAt) {
    if (hp === null || hp > 0) return false;
    deadAt = now; task = null; for (const k of BTN) delete held[k];
    try { bot.stopMoving(); } catch (_) {}
    emit({ event: "died", msg: "the bot died, respawning" });
    return true;
  }
  if (hp !== null && hp > 0) {                       // alive again: go back next to a player
    deadAt = 0;
    const p = realPlayers()[0];
    if (p) { try { bot.teleport({ x: p.location.x + 1.5, y: p.location.y, z: p.location.z + 1.5 }, { dimension: p.dimension, keepVelocity: false }); } catch (_) {} }
    emit({ event: "respawned", msg: "respawned next to a player; inventory is empty" });
    return false;
  }
  inbox.length = 0;                                  // commands for a dead bot are useless
  const waited = now - deadAt;
  if (waited >= 20 && waited % 40 === 20) { try { bot.respawn(); } catch (e) { S.lastErr = "respawn: " + e; } }
  if (waited > 200) {                                // respawn() did not work: end this test, the launcher spawns a new bot
    deadAt = 0; S.fresh = true; S.restart = true; S.launching = 0;
    emit({ event: "warn", msg: "respawn failed, restarting the bot" });
  }
  return true;
}

// ---------------------------------------------------------------- auto swim: head under water / floating with no order -> swim ashore
let wetTicks = 0;
function autoSwim(bot, now) {
  if (!SWIM.auto || task || !inWater(bot)) { wetTicks = 0; return; }
  let g = true; try { g = bot.isOnGround; } catch (_) {}
  if (g && !headUnder(bot)) { wetTicks = 0; return; }      // wading in shallow water is fine
  if (++wetTicks >= (heldList().length ? 200 : 60)) {
    wetTicks = 0;
    setTask({ type: "swim", pos: null, fixed: false, refind: 0 }, 20 * 40);
    emit({ event: "auto_swim", msg: "in deep water with no order, swimming to the shore" });
  }
}

S.onTick = (bot) => {
  try { if (handleDeath(bot, system.currentTick)) return; } catch (e) { S.lastErr = "death: " + e; }
  while (inbox.length) { const m = inbox.shift(); run(m.line, m.ctx); }
  let fighting = false;
  try { fighting = reflexTick(bot, system.currentTick); } catch (e) { S.lastErr = "reflex: " + e; }
  if (fighting) return;      // the reflex owns the bot while a monster is close
  try { applyInputs(bot, system.currentTick); } catch (e) { S.lastErr = "input: " + e; }
  if (blockedNow && task && (task.type === "walkto" || task.type === "mineat")) finish(false, "danger: " + blockedNow + " ahead");
  if (task) { try { runTask(bot); } catch (e) { emit({ event: "error", task: task?.type, msg: String(e) }); task = null; } }
  try { guardNav(bot); } catch (e) { S.lastErr = "safety: " + e; }
  try { autoSwim(bot, system.currentTick); } catch (e) { S.lastErr = "swim: " + e; }
};

system.afterEvents.scriptEventReceive.subscribe(({ id, message, sourceEntity }) => {
  if (id !== "ai:cmd") return;
  const ctx = { src: sourceEntity && sourceEntity.typeId === "minecraft:player" ? sourceEntity : undefined };
  const first = (message ?? "").trim().split(/\s+/)[0].toLowerCase();
  if (alive() && !C[first]) inbox.push({ line: message ?? "", ctx });   // run inside the test loop
  else run(message ?? "", ctx);                                          // commands that do not need the bot yet (or errors)
});

emit({ event: "ready", hint: "/scriptevent ai:cmd spawn   then   /scriptevent ai:cmd help" });
